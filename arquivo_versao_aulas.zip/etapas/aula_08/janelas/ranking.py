"""Janela da Opcao 5: ranking de poder em barras (escala de logaritmo)."""

import customtkinter as ctk

from core.poder import escala_log, formatar_ki
from janelas import base, tema
from janelas.componentes import preparar_foto

LARGURA_BARRA = 300
SOBRESCRITO = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def ki_bonito(ki):
    """'9.0 x 10^25' -> '9.0 × 10²⁵' (na janela da para usar numeros pequenininhos)."""
    texto = formatar_ki(ki)
    if "^" not in texto:
        return texto
    numero, expoente = texto.split("^")
    return numero.replace(" x ", " × ") + expoente.translate(SOBRESCRITO)


def criar_linha(mestre, posicao, personagem, ki, maior, foto):
    """Uma linha do ranking: posicao, foto, nome, barra e valor."""
    linha = ctk.CTkFrame(mestre, fg_color=tema.CARD, corner_radius=8)
    ctk.CTkLabel(linha, text=f"#{posicao}", width=40, font=tema.fonte(16, negrito=True),
                 text_color=tema.DESTAQUE).pack(side="left", padx=(8, 0))
    linha.imagem, texto = preparar_foto(foto, 48, 48, miniatura=True)
    ctk.CTkLabel(linha, image=linha.imagem, text=texto, font=tema.fonte(8)).pack(side="left", padx=8, pady=6)
    ctk.CTkLabel(linha, text=personagem["name"], width=150, anchor="w",
                 font=tema.fonte(14, negrito=True)).pack(side="left")
    barra = ctk.CTkProgressBar(linha, width=LARGURA_BARRA, height=16, progress_color=tema.DESTAQUE)
    barra.set(escala_log(ki, maior))
    barra.pack(side="left", padx=8)
    ctk.CTkLabel(linha, text=ki_bonito(ki), width=110, anchor="e",
                 font=tema.fonte(13, negrito=True)).pack(side="left", padx=(0, 12))
    return linha


def mostrar_ranking(titulo, ranking, fotos, ignorados):
    """ranking = [(personagem, ki), ...] ja em ordem."""
    janela = base.criar_janela("Ranking de poder", 760, 640)
    ctk.CTkLabel(janela, text=f"🏆 {titulo}", font=tema.fonte(20, negrito=True),
                 text_color=tema.DESTAQUE).pack(pady=(16, 4))
    ctk.CTkLabel(janela, text="As barras usam escala de LOGARITMO: cada pedacinho a mais = 10x mais forte.",
                 text_color=tema.TEXTO_SECUNDARIO).pack()
    rolagem = ctk.CTkScrollableFrame(janela, fg_color=tema.FUNDO)
    rolagem.pack(fill="both", expand=True, padx=12, pady=10)
    maior = ranking[0][1]
    for posicao in range(len(ranking)):
        personagem, ki = ranking[posicao]
        criar_linha(rolagem, posicao + 1, personagem, ki, maior, fotos[posicao]).pack(fill="x", pady=4)
    rodape = (f"{ignorados} personagem(ns) ficaram de fora porque o ki é 0 ou desconhecido (\"unknown\"). "
              "Na escala de logaritmo o 0 não cabe: log(0) não existe!")
    ctk.CTkLabel(janela, text=rodape, wraplength=700, text_color=tema.TEXTO_SECUNDARIO,
                 font=tema.fonte(12)).pack(pady=(0, 12))
    base.esperar_fechar(janela)
