"""
Atividade da Aula 6A: ANTES de rodar, cada dupla escreve no caderno quem vence mais
(e mais ou menos quantas vezes em 100). Depois:

    python exemplos/cem_lutas.py Goku Freezer

Rode tambem com Base KI:   python exemplos/cem_lutas.py Goku Freezer ki
"""

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))   # para achar a pasta core/

from core import api, batalha


def achar(nome, personagens):
    achados = api.buscar_personagem(nome, personagens)
    if not achados:
        sys.exit(f"Nao encontrei '{nome}'.")
    return achados[0]


nome_a = sys.argv[1] if len(sys.argv) > 1 else "Goku"
nome_b = sys.argv[2] if len(sys.argv) > 2 else "Freezer"
metrica = sys.argv[3] if len(sys.argv) > 3 else "maxKi"

personagens = api.listar_personagens()
lutador_a = achar(nome_a, personagens)
lutador_b = achar(nome_b, personagens)

vitorias = {lutador_a["name"]: 0, lutador_b["name"]: 0}
for semente in range(100):
    # cada semente diferente = uma luta diferente (mas que se repete igual se rodar de novo)
    resultado = batalha.simular_luta(lutador_a, lutador_b, random.Random(semente), metrica)
    vitorias[resultado["vencedor"]] += 1

print(f"100 lutas usando {metrica}:")
for nome, quantas in vitorias.items():
    print(f"  {nome:<15} {quantas:>3} vitorias  " + "#" * (quantas // 2))
