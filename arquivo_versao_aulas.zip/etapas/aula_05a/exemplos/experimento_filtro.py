"""
Experimento da Aula 5A: filtrar LOCALMENTE x filtrar NO SERVIDOR.

    python exemplos/experimento_filtro.py

Anote os tempos na tabela do quadro. Qual foi mais rapido? Por que?
E repare: a resposta do servidor vem num FORMATO diferente!
"""

import sys
import time
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))   # para achar a pasta core/

from core import api

RACA = "Saiyan"

# 1) LOCAL: a lista dos 58 ja esta no computador (cache); so filtramos com Python
personagens = api.listar_personagens()
inicio = time.perf_counter()
locais = [p for p in personagens if p["race"] == RACA]
tempo_local = (time.perf_counter() - inicio) * 1000
print(f"Local:    {len(locais)} personagens em {tempo_local:.3f} ms")

# 2) SERVIDOR: pedimos para a API filtrar (?race=Saiyan) e esperamos a resposta pela rede
inicio = time.perf_counter()
resposta = requests.get(api.URL_BASE + "/characters", params={"race": RACA},
                        headers=api.CABECALHOS, timeout=10)
tempo_servidor = (time.perf_counter() - inicio) * 1000
dados = resposta.json()
print(f"Servidor: {len(dados)} personagens em {tempo_servidor:.0f} ms")
print(f"URL usada: {resposta.url}")

# 3) A pegadinha do formato
print()
print("Sem filtro, a API devolve:", type(api.pegar_json("/characters")).__name__, "(com 'items')")
print("Com filtro, a API devolve:", type(dados).__name__, "(lista pura!)")
print(f"O filtro local foi umas {tempo_servidor / max(tempo_local, 0.001):.0f} vezes mais rapido.")
