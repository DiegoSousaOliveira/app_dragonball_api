"""Uma funcao para cada opcao do menu. O main.py chama estas funcoes."""

from core import api, imagens
from core import filtros as filtros_core
from janelas import personagem as janela_personagem
from terminal.busca import escolher_personagem
from terminal.menu import escolher_de_lista, ler_numero, mostrar_avisos, mostrar_progresso


def em_construcao(nome):
    print(f"[em construcao] A opcao '{nome}' fica pronta numa proxima aula.")


def baixar_imagens(urls, descricao):
    """Baixa varias imagens mostrando uma barra de progresso. Devolve a lista de imagens."""
    fotos = []
    for numero, url in enumerate(urls, start=1):
        fotos.append(imagens.baixar_imagem(url))
        mostrar_progresso(f"Baixando {descricao}", numero, len(urls))
    return fotos


def abrindo(nome):
    print(f">> Abrindo a janela de {nome} (feche a janela para voltar ao menu)")


def opcao_ver_personagem():
    personagem = escolher_personagem()
    if personagem is None:
        return
    print("Buscando detalhes...")
    detalhe = api.detalhar_personagem(personagem["id"])
    mostrar_avisos()
    print("Baixando imagem...")
    imagem = imagens.baixar_imagem(detalhe["image"])
    urls = []
    for transformacao in detalhe["transformations"]:
        urls.append(transformacao["image"])
    fotos = baixar_imagens(urls, "transformacoes")
    abrindo(detalhe["name"])
    janela_personagem.mostrar_personagem(detalhe, imagem, fotos)


def perguntar_filtros(personagens):
    """Faz as perguntas da busca. Todas sao opcionais (Enter pula)."""
    print("Preencha os filtros (Enter pula):")
    filtros = {
        "nome": input("Nome contem: ").strip(),
        "raca": escolher_de_lista("Raca", filtros_core.valores_unicos(personagens, "race")),
        "afiliacao": escolher_de_lista("Afiliacao", filtros_core.valores_unicos(personagens, "affiliation")),
        "genero": escolher_de_lista("Genero", filtros_core.valores_unicos(personagens, "gender")),
    }
    ordem = ler_numero("Ordenar por: 1 - Nome  2 - Base KI  3 - Total KI (Enter = nome): ", 1, 3, padrao=1)
    criterios = {1: "nome", 2: "ki", 3: "maxKi"}
    return filtros, criterios[ordem]


def mostrar_tabela(achados, total):
    """Imprime os personagens alinhados em colunas."""
    print()
    print(f"{'Nome':<24}{'Raca':<18}{'Base KI':>16}{'Total KI':>20}")
    print("-" * 78)
    for p in achados:
        print(f"{p['name']:<24}{p['race']:<18}{p['ki']:>16}{p['maxKi']:>20}")
    print("-" * 78)
    if not achados:
        print("Nenhum personagem combina com esses filtros.")
    print(f"{len(achados)} de {total} personagens")


def opcao_buscar():
    personagens = api.listar_personagens()
    mostrar_avisos()
    filtros, criterio = perguntar_filtros(personagens)
    achados = filtros_core.filtrar(personagens, filtros["nome"], filtros["raca"],
                                   filtros["afiliacao"], filtros["genero"])
    achados = filtros_core.ordenar(achados, criterio)
    mostrar_tabela(achados, len(personagens))


def opcao_batalha():
    em_construcao("Batalha")


def opcao_planetas():
    em_construcao("Planetas")


def opcao_ranking():
    em_construcao("Ranking de poder")


def opcao_quiz():
    em_construcao("Quem e esse personagem?")


def opcao_raio_x():
    em_construcao("Raio-X da API")
