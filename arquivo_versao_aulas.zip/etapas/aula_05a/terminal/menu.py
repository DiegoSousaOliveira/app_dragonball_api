"""Menu principal e funcoes para ler respostas do usuario sem o programa quebrar."""

from core import api

LARGURA = 40

ITENS_DO_MENU = [
    "1 - Ver personagem",
    "2 - Buscar personagens",
    "3 - Batalha",
    "4 - Planetas",
    "5 - Ranking de poder",
    "6 - Quem e esse personagem?",
    "7 - Raio-X da API (Redes)",
    "0 - Sair",
]


def titulo(texto):
    print("=" * LARGURA)
    print(texto.center(LARGURA))
    print("=" * LARGURA)


def mostrar_menu():
    print()
    titulo("DRAGON BALL DEX")
    print()
    for item in ITENS_DO_MENU:
        print("    " + item)
    print()


def ler_opcao(opcoes_validas, pergunta="opcao: "):
    """Pergunta ate o usuario digitar um numero que esteja em 'opcoes_validas'."""
    while True:
        texto = input(pergunta).strip()
        if not texto.isdigit():
            print("Digite apenas o numero da opcao.")
            continue
        numero = int(texto)
        if numero in opcoes_validas:
            return numero
        print(f"A opcao {numero} nao existe. Escolha uma das opcoes do menu.")


def ler_sim_nao(pergunta):
    """Devolve True para 's' e False para 'n'. Insiste ate receber uma das duas."""
    while True:
        resposta = input(pergunta).strip().lower()
        if resposta in ("s", "sim"):
            return True
        if resposta in ("n", "nao"):
            return False
        print("Responda s ou n.")


def ler_numero(pergunta, minimo, maximo, padrao=None):
    """Le um numero entre minimo e maximo. Enter vazio devolve 'padrao' (se houver)."""
    while True:
        texto = input(pergunta).strip()
        if texto == "" and padrao is not None:
            return padrao
        if texto.isdigit() and minimo <= int(texto) <= maximo:
            return int(texto)
        print(f"Digite um numero de {minimo} a {maximo}.")


def escolher_de_lista(titulo, opcoes):
    """Mostra as opcoes numeradas. Devolve a escolhida, ou None se o usuario apertar Enter."""
    print(f"{titulo}:")
    for numero, opcao in enumerate(opcoes, start=1):
        print(f"  {numero:>2} - {opcao}")
    escolha = ler_numero("Numero (Enter = qualquer): ", 1, len(opcoes), padrao=0)
    if escolha == 0:
        return None
    return opcoes[escolha - 1]


def barra_de_progresso(atual, total, largura=10):
    """Texto tipo '[#####     ] 5/10'."""
    cheios = round(largura * atual / total)
    return "[" + "#" * cheios + " " * (largura - cheios) + f"] {atual}/{total}"


def mostrar_progresso(descricao, atual, total):
    # "\r" volta o cursor para o comeco da linha: a barra e redesenhada no mesmo lugar
    print(f"\r{descricao} {barra_de_progresso(atual, total)}", end="")
    if atual == total:
        print()


def mostrar_avisos():
    """Mostra os recados do core (ex.: '(sem internet: usando dados salvos)')."""
    for aviso in api.pegar_avisos():
        print(aviso)
