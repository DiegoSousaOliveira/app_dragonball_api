"""Perguntar o nome de um personagem e encontra-lo na lista."""

from core import api
from terminal.menu import mostrar_avisos


def escolher_personagem(pergunta="Nome do personagem: "):
    """Pergunta um nome e devolve o personagem (dicionario), ou None se nao achar."""
    personagens = api.listar_personagens()
    mostrar_avisos()
    nome = input(pergunta).strip()
    for personagem in personagens:
        if personagem["name"].lower() == nome.lower():
            return personagem
    print(f'Nao encontrei "{nome}".')
    return None
