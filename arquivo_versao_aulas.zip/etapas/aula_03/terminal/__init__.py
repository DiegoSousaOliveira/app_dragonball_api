"""Tudo que conversa com o usuario pelo terminal (print e input) mora aqui."""
