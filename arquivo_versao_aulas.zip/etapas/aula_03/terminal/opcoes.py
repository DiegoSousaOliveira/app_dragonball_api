"""Uma funcao para cada opcao do menu. O main.py chama estas funcoes."""

from terminal.busca import escolher_personagem
from terminal.menu import LARGURA


def em_construcao(nome):
    print(f"[em construcao] A opcao '{nome}' fica pronta numa proxima aula.")


def mostrar_ficha(personagem):
    """Mostra os dados do personagem em texto (antes de termos janelas)."""
    print("=" * LARGURA)
    print(personagem["name"])
    print("-" * LARGURA)
    print(f"Raca:       {personagem['race']}")
    print(f"Genero:     {personagem['gender']}")
    print(f"Base KI:    {personagem['ki']}")
    print(f"Total KI:   {personagem['maxKi']}")
    print(f"Afiliacao:  {personagem['affiliation']}")
    print("=" * LARGURA)


def opcao_ver_personagem():
    personagem = escolher_personagem()
    if personagem is not None:
        mostrar_ficha(personagem)


def opcao_buscar():
    em_construcao("Buscar personagens")


def opcao_batalha():
    em_construcao("Batalha")


def opcao_planetas():
    em_construcao("Planetas")


def opcao_ranking():
    em_construcao("Ranking de poder")


def opcao_quiz():
    em_construcao("Quem e esse personagem?")


def opcao_raio_x():
    em_construcao("Raio-X da API")
