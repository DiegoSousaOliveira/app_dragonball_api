"""
Dragon Ball Dex - programa principal.

Uso:
    python main.py                     -> abre o menu
    python main.py --atualizar-cache   -> apaga o cache e baixa tudo de novo
"""

import sys

from core import api
from terminal import opcoes
from terminal.menu import ler_opcao, mostrar_menu

# Cada numero do menu aponta para a FUNCAO que cuida dele.
# Repare: sem parenteses! Guardamos a funcao, nao chamamos ela agora.
ACOES = {
    1: opcoes.opcao_ver_personagem,
    2: opcoes.opcao_buscar,
    3: opcoes.opcao_batalha,
    4: opcoes.opcao_planetas,
    5: opcoes.opcao_ranking,
    6: opcoes.opcao_quiz,
    7: opcoes.opcao_raio_x,
}


def executar(acao):
    """Roda uma opcao sem deixar um erro de rede derrubar o programa."""
    try:
        acao()
    except api.ErroDeApi as erro:
        print(f"[ERRO] {erro}")


def principal():
    if "--atualizar-cache" in sys.argv:
        api.limpar_cache()
        print("Cache apagado: os dados serao baixados de novo.")
    while True:
        mostrar_menu()
        opcao = ler_opcao(list(ACOES) + [0])
        if opcao == 0:
            break
        executar(ACOES[opcao])      # aqui sim: os parenteses chamam a funcao
    print("Ate a proxima!")


if __name__ == "__main__":
    try:
        principal()
    except (KeyboardInterrupt, EOFError):
        # Ctrl+C (ou Ctrl+Z/Ctrl+D) encerra com educacao, sem mensagem de erro gigante
        print("\nPrograma encerrado. Ate a proxima!")
