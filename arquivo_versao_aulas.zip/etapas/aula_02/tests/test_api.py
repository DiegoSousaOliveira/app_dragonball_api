"""Testes das partes do core/api.py que nao precisam de internet."""

from core.api import extrair_itens, limpar_nomes


def test_extrair_itens_com_envelope():
    resposta = {"items": [{"id": 1}], "meta": {}, "links": {}}
    assert extrair_itens(resposta) == [{"id": 1}]


def test_extrair_itens_lista_pura():
    assert extrair_itens([{"id": 1}, {"id": 2}]) == [{"id": 1}, {"id": 2}]


def test_limpar_nomes():
    itens = limpar_nomes([{"name": "Grand Priest "}, {"name": "Goku"}])
    assert [item["name"] for item in itens] == ["Grand Priest", "Goku"]
