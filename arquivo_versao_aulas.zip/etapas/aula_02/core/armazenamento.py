"""Guardar e ler arquivos JSON (cache, historico, recordes...)."""

import json
from pathlib import Path

# Pasta do projeto, descoberta a partir DESTE arquivo (core/armazenamento.py -> sobe 2 niveis).
# Assim o programa acha suas pastas mesmo se for aberto de outro lugar.
PASTA_PROJETO = Path(__file__).resolve().parent.parent
PASTA_DADOS = PASTA_PROJETO / "dados"
PASTA_CACHE = PASTA_PROJETO / "cache"


def salvar_json(caminho, dados):
    """Grava 'dados' (lista, dicionario...) num arquivo JSON, criando a pasta se precisar."""
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with open(caminho, "w", encoding="utf-8") as arquivo:
        json.dump(dados, arquivo, ensure_ascii=False, indent=2)


def carregar_json(caminho, padrao=None):
    """Le um arquivo JSON. Se ele nao existir ou estiver estragado, devolve 'padrao'."""
    try:
        with open(caminho, encoding="utf-8") as arquivo:
            return json.load(arquivo)
    except (OSError, ValueError):
        return padrao
