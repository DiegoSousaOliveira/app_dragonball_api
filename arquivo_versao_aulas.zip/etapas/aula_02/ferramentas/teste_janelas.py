"""
Etapa 0b: testa o padrao "raiz escondida + CTkToplevel + wait_window".

Abre 5 janelas seguidas (cada uma fecha sozinha depois de 1,5 s) e,
entre uma e outra, o "terminal" volta a ter o controle.
Uso:  python ferramentas/teste_janelas.py [--plano-b] [--print]
  --plano-b  usa Tkinter puro em vez de CustomTkinter
  --print    salva um print de tela de cada janela em docs/brutos/ (so Windows/Mac)
"""

import io
import sys

import requests

QUANTAS = 5
PLANO_B = "--plano-b" in sys.argv
TIRAR_PRINT = "--print" in sys.argv

if PLANO_B:
    import tkinter as tk
else:
    import customtkinter as ctk

from PIL import Image

_raiz = None


def obter_raiz():
    global _raiz
    if _raiz is None:
        if PLANO_B:
            _raiz = tk.Tk()
        else:
            ctk.set_appearance_mode("dark")
            _raiz = ctk.CTk()
        _raiz.withdraw()
    return _raiz


def criar_janela(titulo, largura, altura):
    if PLANO_B:
        janela = tk.Toplevel(obter_raiz(), bg="#1E1F22")
    else:
        janela = ctk.CTkToplevel(obter_raiz())
    janela.title(f"Dragon Ball Dex - {titulo}")
    x = (janela.winfo_screenwidth() - largura) // 2
    y = (janela.winfo_screenheight() - altura) // 2
    janela.geometry(f"{largura}x{altura}+{x}+{y}")
    janela.attributes("-topmost", True)
    janela.after(300, lambda: janela.attributes("-topmost", False))
    return janela


def baixar_goku():
    url = "https://dragonball-api.com/characters/goku_normal.webp"
    try:
        r = requests.get(url, timeout=10, headers={"User-Agent": "DragonBallDex-Escola/1.0"})
        return Image.open(io.BytesIO(r.content))
    except Exception as erro:
        print("  (sem imagem:", erro, ")")
        return None


def tirar_print(janela, numero):
    from PIL import ImageGrab
    janela.update()
    x, y = janela.winfo_rootx(), janela.winfo_rooty()
    w, h = janela.winfo_width(), janela.winfo_height()
    caminho = f"docs/brutos/janela_{'tk' if PLANO_B else 'ctk'}_{numero}.png"
    ImageGrab.grab(bbox=(x, y, x + w, y + h)).save(caminho)
    print("  print salvo em", caminho)


def mostrar(numero, imagem):
    janela = criar_janela(f"teste {numero}", 360, 480)
    if PLANO_B:
        from PIL import ImageTk
        rotulo = tk.Label(janela, text=f"Janela {numero} de {QUANTAS}", bg="#1E1F22", fg="#FAC02D",
                          font=("Segoe UI", 18, "bold"))
        rotulo.pack(pady=10)
        if imagem is not None:
            janela.foto = ImageTk.PhotoImage(imagem.resize((150, 338)))
            tk.Label(janela, image=janela.foto, bg="#3A3D42").pack()
    else:
        ctk.CTkLabel(janela, text=f"Janela {numero} de {QUANTAS} 🐉", text_color="#FAC02D",
                     font=ctk.CTkFont(size=22, weight="bold")).pack(pady=10)
        if imagem is not None:
            janela.foto = ctk.CTkImage(light_image=imagem, dark_image=imagem, size=(150, 338))
            ctk.CTkLabel(janela, image=janela.foto, text="", fg_color="#3A3D42").pack()
    if TIRAR_PRINT:
        janela.after(800, lambda: tirar_print(janela, numero))
    janela.after(1500, janela.destroy)
    janela.wait_window()


def principal():
    imagem = baixar_goku()
    for numero in range(1, QUANTAS + 1):
        print(f"[terminal] abrindo janela {numero}...")
        mostrar(numero, imagem)
        print(f"[terminal] janela {numero} fechou, voltei ao controle")
    if _raiz is not None:
        _raiz.update()
        _raiz.destroy()
    print("[OK] todas as janelas abriram e fecharam")


if __name__ == "__main__":
    principal()
