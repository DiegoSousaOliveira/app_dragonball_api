"""
Prototipo do professor, depois da "Caca aos bugs" (Aula 1).

Cada correcao esta marcada com o numero do bug que ela resolve.
Compare com exemplos/api_test_original.py.
"""

import requests

URL_PERSONAGENS = "https://dragonball-api.com/api/characters"


def extrair_itens(resposta_json):
    """A API devolve {"items": [...]} paginado OU uma lista pura quando ha filtro."""
    # BUG 8: com filtro (?race=Saiyan) a resposta e uma lista, e lista nao tem .get()
    if isinstance(resposta_json, dict):
        return resposta_json.get("items", [])
    return resposta_json


def baixar_personagens():
    """Baixa TODOS os personagens. Se a rede falhar, devolve uma lista vazia."""
    try:
        # BUG 1: limit=100 traz os 58 de uma vez (sem ele vinham so 10)
        # BUG 6: timeout=10 -> desiste depois de 10 segundos em vez de esperar para sempre
        resposta = requests.get(URL_PERSONAGENS, params={"limit": 100}, timeout=10)
        resposta.raise_for_status()      # status 4xx ou 5xx vira erro
        return extrair_itens(resposta.json())
    except requests.RequestException:
        # BUG 6: sem internet o programa avisa, em vez de quebrar
        print("Nao consegui falar com a API. Verifique a internet.")
        return []


def menu_opcao():
    print("=" * 40)
    print("Menu De Opcoes".center(40))
    print("=" * 40)
    print("""
    \r1 - Ver personagem
    \r0 - Sair
    """)


def ler_opcao():
    """Pergunta a opcao ate o usuario digitar um numero."""
    # BUG 4: int("abc") quebrava o programa; agora testamos antes de converter
    while True:
        texto = input("opcao: ").strip()
        if texto.isdigit():
            return int(texto)
        print("Digite apenas o numero da opcao.")


def get_personagem(personagens: list, nome_pers: str):
    """Procura o personagem pelo nome. Devolve um DICIONARIO, ou None se nao achar."""
    procurado = nome_pers.strip().lower()
    for personagem in personagens:
        # BUG 2: comparamos tudo em minusculas, entao "goku" acha "Goku"
        if personagem.get("name", "").strip().lower() == procurado:
            # BUG 7: dicionario com nomes claros, em vez de dados[0], dados[1]...
            return {
                "nome": personagem.get("name"),
                "ki": personagem.get("ki"),
                "max_ki": personagem.get("maxKi"),
                "raca": personagem.get("race"),
            }
    return None


personagens = baixar_personagens()
print(f"{len(personagens)} personagens carregados.")

while True:
    menu_opcao()
    opcao = ler_opcao()

    if opcao == 0:
        # BUG 5: agora existe um jeito de sair
        print("Ate a proxima!")
        break
    elif opcao == 1:
        nome_personagem = input("Nome do personagem: ")
        print("=" * 40)
        dados_personagem = get_personagem(personagens, nome_personagem)
        if dados_personagem is None:
            # BUG 3: antes, dados_personagem[0] numa lista vazia dava IndexError
            print(f'Nao encontrei "{nome_personagem}".')
        else:
            print(f"Nome: {dados_personagem['nome']}")
            print(f"Ki: {dados_personagem['ki']}")
            print(f"MaxKi: {dados_personagem['max_ki']}")
            print(f"Raca: {dados_personagem['raca']}")
    else:
        # BUG 5: opcao invalida nao e mais ignorada em silencio
        print(f"A opcao {opcao} nao existe.")
