"""
Ola, janela! - o primeiro teste da Aula 0.

Se esta janela abrir e o botao trocar o texto, o computador esta pronto:
Python, CustomTkinter e a parte grafica (Tkinter) estao funcionando.

Rode com:  python exemplos/ola_janela.py
"""

import customtkinter as ctk

ctk.set_appearance_mode("dark")

janela = ctk.CTk()
janela.title("Dragon Ball Dex - Ola, janela!")
janela.geometry("360x200")

texto = ctk.CTkLabel(janela, text="Clique no botao abaixo", font=ctk.CTkFont(size=18))
texto.pack(pady=30)

cliques = 0


def quando_clicar():
    """Esta funcao roda TODA vez que o botao e clicado (isso se chama 'evento')."""
    global cliques
    cliques = cliques + 1
    texto.configure(text=f"Kamehameha! 🔥 ({cliques}x)")


botao = ctk.CTkButton(janela, text="Clique aqui", command=quando_clicar)
botao.pack()

# mainloop() deixa a janela "viva", esperando cliques, ate alguem fecha-la.
janela.mainloop()
