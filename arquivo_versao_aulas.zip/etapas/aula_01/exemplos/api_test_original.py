import requests

resp = requests.get("https://dragonball-api.com/api/characters").json()

def menu_opcao():
    print("=" * 40)
    print("Menu De Opções".center(40))
    print("=" * 40)
    print("""
    \r1 - Ver personagem
    """)

def get_personagem(dado_api: dict, nome_perns: str) -> list:
    items = dado_api.get("items")
    dados_pers = []

    for i in items:
        if i.get("name") == nome_perns:
            dados_pers.append(i.get("name"))
            dados_pers.append(i.get("ki"))
            dados_pers.append(i.get("maxKi"))
            dados_pers.append(i.get("race"))

    return dados_pers


while True:
    menu_opcao()
    opcao = int(input("opção: "))

    if opcao == 1:
        nome_personagem = input("Nome do personagem: ")
        print("=" * 40)
        dados_personagem = get_personagem(resp, nome_personagem)
        print(f"Nome: {dados_personagem[0]}")
        print(f"Ki: {dados_personagem[1]}")
        print(f"MaxKi: {dados_personagem[2]}")
        print(f"Raça: {dados_personagem[3]}")
