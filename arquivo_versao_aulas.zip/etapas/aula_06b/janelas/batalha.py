"""Janela da Opcao 3: dois cards frente a frente, barras de vida e a narracao da luta."""

import customtkinter as ctk

from core import batalha
from janelas import base, tema
from janelas.componentes import BarraDeVida, CartaoPersonagem


class JanelaBatalha:
    """Guarda a luta e os pedacos da janela que mudam (barras, narracao, botoes)."""

    def __init__(self, personagem_a, personagem_b, fotos, metrica):
        self.luta = batalha.iniciar_luta(personagem_a, personagem_b, metrica)
        self.resultado = None            # fica preenchido quando a luta acabar
        titulo = f"{personagem_a['name']} x {personagem_b['name']}"
        self.janela = base.criar_janela(titulo, 820, 560)
        self.barras = {}
        self.criar_lado("a", personagem_a, fotos[0], coluna=0)
        self.criar_centro()
        self.criar_lado("b", personagem_b, fotos[1], coluna=2)

    def criar_lado(self, lado, personagem, foto, coluna):
        """Um card pequeno com a barra de vida embaixo."""
        coluna_frame = ctk.CTkFrame(self.janela, fg_color="transparent")
        coluna_frame.grid(row=0, column=coluna, padx=16, pady=16, sticky="n")
        CartaoPersonagem(coluna_frame, personagem, foto, largura=210, altura_foto=230).pack()
        self.barras[lado] = BarraDeVida(coluna_frame, largura=210)
        self.barras[lado].pack(pady=(10, 0))

    def criar_centro(self):
        """No meio: o 'VS', a caixa de narracao e os botoes."""
        centro = ctk.CTkFrame(self.janela, fg_color="transparent")
        centro.grid(row=0, column=1, pady=16, sticky="n")
        ctk.CTkLabel(centro, text="VS", font=tema.fonte(36, negrito=True),
                     text_color=tema.DESTAQUE).pack()
        self.narracao = ctk.CTkTextbox(centro, width=300, height=380, wrap="word",
                                       font=tema.fonte(13), fg_color=tema.CARD)
        self.narracao.pack(pady=10)
        self.botao_lutar = tema.botao(centro, "Lutar! 👊", self.lutar)
        self.botao_lutar.pack(pady=(0, 8))
        tema.botao(centro, "Fechar", self.janela.destroy).pack()

    def escrever(self, frase):
        """Acrescenta uma linha na narracao e rola para o fim."""
        self.narracao.insert("end", frase + "\n\n")
        self.narracao.see("end")

    def atualizar_barras(self):
        self.barras["a"].atualizar(self.luta["a"]["hp"])
        self.barras["b"].atualizar(self.luta["b"]["hp"])

    def lutar(self):
        """Versao 1 (Aula 6B): a luta inteira de uma vez, sem animacao."""
        self.botao_lutar.configure(state="disabled")
        while not batalha.luta_acabou(self.luta):
            self.escrever(batalha.jogar_rodada(self.luta))
        self.atualizar_barras()
        self.terminar()

    def terminar(self):
        self.resultado = batalha.resultado(self.luta)
        self.escrever(f"🏆 {self.resultado['vencedor']} venceu em {self.resultado['rodadas']} rodadas!")


def mostrar_batalha(personagem_a, personagem_b, fotos, metrica):
    """Abre a janela da luta. Quando ela fecha, devolve o resultado (ou None se nao lutaram)."""
    tela = JanelaBatalha(personagem_a, personagem_b, fotos, metrica)
    base.esperar_fechar(tela.janela)
    return tela.resultado
