"""Janela da Opcao 7: grafico de barras com os tempos das requisicoes."""

import customtkinter as ctk

from janelas import base, tema

LARGURA = 760
ALTURA = 380
MARGEM = 50


def desenhar_barras(tela, grupos):
    """grupos = [(nome, [ms, ms, ...], cor), ...]. Uma barra por requisicao, lado a lado."""
    total = sum(len(tempos) for nome, tempos, cor in grupos)
    maior = max(max(tempos) for nome, tempos, cor in grupos)
    largura_barra = (LARGURA - 2 * MARGEM) / total
    x = MARGEM
    fonte = (tema.escolher_fonte(), 9)
    for nome, tempos, cor in grupos:
        inicio_do_grupo = x
        for ms in tempos:
            altura = (ALTURA - 2 * MARGEM) * ms / maior          # regra de tres
            topo = ALTURA - MARGEM - altura
            tela.create_rectangle(x + 3, topo, x + largura_barra - 3, ALTURA - MARGEM, fill=cor, width=0)
            tela.create_text(x + largura_barra / 2, topo - 8, text=f"{ms:.0f}", fill=tema.TEXTO, font=fonte)
            x += largura_barra
        media = sum(tempos) / len(tempos)
        meio = (inicio_do_grupo + x) / 2
        tela.create_text(meio, ALTURA - MARGEM + 18, text=f"{nome}  (média {media:.0f} ms)",
                         fill=cor, font=(tema.escolher_fonte(), 12, "bold"))
    tela.create_line(MARGEM, ALTURA - MARGEM, LARGURA - MARGEM, ALTURA - MARGEM, fill=tema.TEXTO_SECUNDARIO)


def mostrar_grafico(titulo, grupos, explicacao=""):
    """Abre a janela com o grafico e so volta quando ela for fechada."""
    janela = base.criar_janela(titulo, LARGURA + 40, ALTURA + 150)
    ctk.CTkLabel(janela, text=f"📶 {titulo}", font=tema.fonte(20, negrito=True),
                 text_color=tema.DESTAQUE).pack(pady=(16, 0))
    ctk.CTkLabel(janela, text="Tempo de cada requisição em milissegundos (ms). Barra mais alta = mais lenta.",
                 text_color=tema.TEXTO_SECUNDARIO).pack()
    # O Canvas e uma "tela de pintura": desenhamos retangulos e textos por coordenadas (x, y)
    tela = ctk.CTkCanvas(janela, width=LARGURA, height=ALTURA, bg=tema.FUNDO, highlightthickness=0)
    tela.pack(pady=6)
    desenhar_barras(tela, grupos)
    if explicacao:
        ctk.CTkLabel(janela, text=explicacao, wraplength=LARGURA, justify="left").pack(padx=20)
    base.esperar_fechar(janela)
