"""
Cliente da Dragon Ball API: toda conversa com a internet passa por aqui.

Para cada dado, tentamos nesta ordem:
  1. o cache em disco (pasta cache/), se tiver menos de 24 horas
  2. a internet
  3. o cache vencido (velho, mas melhor que nada)
  4. o snapshot (pasta dados/): uma "fotografia" dos dados que vem junto com o projeto

Rode "python -m core.api" para ver os 58 nomes.
"""

import difflib
import time
import unicodedata
from datetime import datetime

import requests

from core.armazenamento import PASTA_CACHE, PASTA_DADOS, carregar_json, salvar_json

URL_BASE = "https://dragonball-api.com/api"
CABECALHOS = {"User-Agent": "DragonBallDex-Escola/1.0"}   # nos apresentamos ao servidor
TIMEOUT = 10                                             # segundos
VALIDADE_CACHE = 24 * 60 * 60                            # 24 horas, em segundos

# Cada requisicao (da rede ou do cache) vira um dicionario nesta lista. A Opcao 7 mostra tudo.
LOG_REQUISICOES = []
# Recados para o terminal mostrar (o core nao faz print).
AVISOS = []
# Ligado pela Opcao 7 para simular "cabo de rede desligado".
modo_offline = False

# Uma Session reaproveita a mesma conexao para varias requisicoes (mais rapido).
# Na Aula 10 vamos medir essa diferenca.
sessao = requests.Session()
sessao.headers.update(CABECALHOS)


class ErroDeApi(Exception):
    """Um erro que ja vem com mensagem amigavel em portugues."""


class ApiForaDoAr(ErroDeApi):
    """Sem internet, demorou demais ou o servidor quebrou: vale a pena usar dados salvos."""


# ----------------------------------------------------------------------
# Registro de requisicoes
# ----------------------------------------------------------------------

def registrar(url, status, ms, tamanho, tipo, origem):
    """Anota uma requisicao no LOG_REQUISICOES."""
    LOG_REQUISICOES.append({
        "hora": datetime.now().strftime("%H:%M:%S"),
        "metodo": "GET",
        "url": url,
        "status": status,
        "ms": ms,
        "bytes": tamanho,
        "content_type": tipo,
        "origem": origem,
    })


def avisar_sem_internet():
    aviso = "(sem internet: usando dados salvos)"
    if aviso not in AVISOS:
        AVISOS.append(aviso)


def pegar_avisos():
    """Entrega os avisos pendentes (e esvazia a lista)."""
    avisos = list(AVISOS)
    AVISOS.clear()
    return avisos


# ----------------------------------------------------------------------
# Falar com a internet
# ----------------------------------------------------------------------

def baixar(url, params=None):
    """Faz um GET e devolve a resposta do requests. Erros de rede viram ApiForaDoAr."""
    if modo_offline:
        raise ApiForaDoAr("Modo offline ligado: nao vou usar a internet.")
    try:
        resposta = sessao.get(url, params=params, timeout=TIMEOUT)
    except requests.Timeout:
        raise ApiForaDoAr(f"A API demorou mais de {TIMEOUT} segundos para responder.")
    except requests.ConnectionError:
        raise ApiForaDoAr("Sem conexao com a API. Verifique a internet.")
    except requests.RequestException:
        raise ErroDeApi("Nao consegui fazer o pedido para a API.")
    ms = int(resposta.elapsed.total_seconds() * 1000)
    tipo = resposta.headers.get("Content-Type", "-")
    registrar(resposta.url, resposta.status_code, ms, len(resposta.content), tipo, "rede")
    return resposta


def pegar_json(caminho, params=None):
    """GET em um caminho da API ('/characters') ou URL completa. Devolve o JSON ja convertido."""
    url = caminho if caminho.startswith("http") else URL_BASE + caminho
    resposta = baixar(url, params)
    if resposta.status_code >= 500:
        raise ApiForaDoAr(f"O servidor da API esta com problemas (erro {resposta.status_code}).")
    try:
        resposta.raise_for_status()           # 4xx vira HTTPError
    except requests.HTTPError:
        raise ErroDeApi(f"A API recusou o pedido (erro {resposta.status_code}).")
    if not resposta.content:
        raise ErroDeApi("A API respondeu, mas sem dados.")
    try:
        return resposta.json()
    except ValueError:                        # o JSONDecodeError e um tipo de ValueError
        raise ErroDeApi("A API respondeu algo que nao e JSON.")


def extrair_itens(resposta_json):
    """A API devolve {"items": [...]} paginado OU uma lista pura quando ha filtro."""
    if isinstance(resposta_json, dict):
        return resposta_json.get("items", [])
    return resposta_json


def baixar_lista_completa(caminho):
    """Estrategia A: pede tudo de uma vez (limit=100). Se nao vier tudo, usa a estrategia B."""
    resposta = pegar_json(caminho, {"limit": 100})
    itens = extrair_itens(resposta)
    total = len(itens)
    if isinstance(resposta, dict):
        total = resposta.get("meta", {}).get("totalItems", total)
    if len(itens) >= total:
        return itens
    return baixar_pagina_por_pagina(caminho)


def baixar_pagina_por_pagina(caminho):
    """Estrategia B: pede a pagina 1 e vai seguindo o link 'next' ate ele vir vazio."""
    itens = []
    url = URL_BASE + caminho
    while url:
        resposta = pegar_json(url)
        itens.extend(extrair_itens(resposta))
        url = resposta.get("links", {}).get("next")
    return itens


# ----------------------------------------------------------------------
# Cache em disco e snapshot
# ----------------------------------------------------------------------

def arquivo_do_cache(nome):
    return PASTA_CACHE / "json" / f"{nome}.json"


def salvar_cache(nome, dados):
    salvar_json(arquivo_do_cache(nome), {"salvo_em": time.time(), "dados": dados})


def ler_cache(nome, validade=VALIDADE_CACHE):
    """Devolve os dados guardados, ou None se nao existirem ou forem mais velhos que 'validade'.
    validade=None aceita qualquer idade."""
    arquivo = arquivo_do_cache(nome)
    guardado = carregar_json(arquivo)
    if guardado is None:
        return None
    idade = time.time() - guardado["salvo_em"]
    if validade is not None and idade > validade:
        return None
    registrar(f"cache/json/{nome}.json", "-", 0, arquivo.stat().st_size, "application/json", "cache")
    return guardado["dados"]


def limpar_cache():
    """Apaga os JSON do cache (usado por 'python main.py --atualizar-cache')."""
    for arquivo in (PASTA_CACHE / "json").glob("*.json"):
        arquivo.unlink()


def obter(nome_cache, caminho, lista_completa=False):
    """Cache valido -> internet -> cache vencido. Se tudo falhar, levanta ApiForaDoAr."""
    dados = ler_cache(nome_cache)
    if dados is not None:
        return dados
    try:
        if lista_completa:
            dados = baixar_lista_completa(caminho)
        else:
            dados = pegar_json(caminho)
    except ApiForaDoAr:
        dados = ler_cache(nome_cache, validade=None)
        if dados is None:
            raise
        avisar_sem_internet()
        return dados
    salvar_cache(nome_cache, dados)
    return dados


def carregar_snapshot(nome_arquivo):
    """Ultimo recurso: a fotografia dos dados guardada na pasta dados/."""
    dados = carregar_json(PASTA_DADOS / nome_arquivo)
    if dados is None:
        raise ApiForaDoAr("Sem internet e sem dados salvos. Conecte-se e tente de novo.")
    avisar_sem_internet()
    return dados


def procurar_por_id(itens, id_procurado):
    for item in itens:
        if item["id"] == id_procurado:
            return item
    raise ErroDeApi(f"Nao encontrei nada com o id {id_procurado}.")


def limpar_nomes(itens):
    """Alguns nomes vem com espaco no fim ('Grand Priest '). Tiramos esse espaco."""
    for item in itens:
        item["name"] = item["name"].strip()
    return itens


# ----------------------------------------------------------------------
# Funcoes que o resto do programa usa
# ----------------------------------------------------------------------

def listar_personagens():
    """Os 58 personagens (lista de dicionarios)."""
    try:
        itens = obter("personagens", "/characters", lista_completa=True)
    except ApiForaDoAr:
        itens = carregar_snapshot("snapshot_personagens.json")
    return limpar_nomes(itens)


def detalhar_personagem(id_personagem):
    """Um personagem com 'originPlanet' (planeta de origem) e 'transformations'."""
    try:
        detalhe = obter(f"personagem_{id_personagem}", f"/characters/{id_personagem}")
    except ApiForaDoAr:
        detalhe = procurar_por_id(carregar_snapshot("snapshot_personagens.json"), id_personagem)
    limpar_nomes([detalhe])
    return detalhe


def listar_planetas():
    """Os 20 planetas."""
    try:
        itens = obter("planetas", "/planets", lista_completa=True)
    except ApiForaDoAr:
        itens = carregar_snapshot("snapshot_planetas.json")
    return limpar_nomes(itens)


def detalhar_planeta(id_planeta):
    """Um planeta com a lista 'characters' (quem mora la)."""
    try:
        detalhe = obter(f"planeta_{id_planeta}", f"/planets/{id_planeta}")
    except ApiForaDoAr:
        detalhe = procurar_por_id(carregar_snapshot("snapshot_planetas.json"), id_planeta)
    limpar_nomes([detalhe])
    limpar_nomes(detalhe.get("characters", []))
    return detalhe


# ----------------------------------------------------------------------
# Busca tolerante (acentos, maiusculas, pedacos do nome, erros de digitacao)
# ----------------------------------------------------------------------

def tirar_acentos(texto):
    """'Kaiō del Norte' -> 'Kaio del Norte'."""
    # NFD separa a letra do acento: 'é' vira 'e' + '´'. Depois jogamos os acentos fora.
    separado = unicodedata.normalize("NFD", texto)
    sem_acento = ""
    for caractere in separado:
        if unicodedata.category(caractere) != "Mn":       # Mn = marca de acento
            sem_acento += caractere
    return sem_acento


def normalizar(texto):
    """'  Célula ' -> 'celula': sem acentos, minusculo e sem espacos nas pontas."""
    return tirar_acentos(texto).strip().lower()


def buscar_personagem(texto, personagens):
    """Devolve [o personagem com nome identico] ou [todos que CONTEM o texto] ou []."""
    procurado = normalizar(texto)
    exatos = []
    parciais = []
    for personagem in personagens:
        nome = normalizar(personagem["name"])
        if nome == procurado:
            exatos.append(personagem)
        elif procurado in nome:
            parciais.append(personagem)
    if exatos:
        return exatos
    return parciais


def sugerir_personagem(texto, personagens):
    """Para quem digitou errado: devolve o personagem de nome mais PARECIDO, ou None."""
    por_nome = {}
    for personagem in personagens:
        por_nome[normalizar(personagem["name"])] = personagem
    parecidos = difflib.get_close_matches(normalizar(texto), list(por_nome), n=1, cutoff=0.6)
    if parecidos:
        return por_nome[parecidos[0]]
    return None


if __name__ == "__main__":
    personagens = listar_personagens()
    for personagem in personagens:
        print(personagem["id"], personagem["name"])
    print(len(personagens), "personagens")
    for aviso in pegar_avisos():
        print(aviso)
