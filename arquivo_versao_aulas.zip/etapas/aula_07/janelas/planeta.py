"""Janelas da Opcao 4: um planeta (com seus moradores) ou a grade de todos os planetas."""

import customtkinter as ctk

from janelas import base, tema
from janelas.componentes import RAIO, MiniCartao, preparar_foto, selo_planeta
from janelas.grade import abrir_cartao

LARGURA_FOTO = 380


def criar_cartao_planeta(mestre, planeta, imagem):
    """Card do planeta: foto, nome, selo Destruido/Preservado e descricao."""
    cartao = ctk.CTkFrame(mestre, corner_radius=RAIO, fg_color=tema.CARD)
    cartao.imagem, texto = preparar_foto(imagem, LARGURA_FOTO, 250, miniatura=True)
    ctk.CTkLabel(cartao, image=cartao.imagem, text=texto, compound="center").pack()
    linha = ctk.CTkFrame(cartao, fg_color="transparent")
    linha.pack(fill="x", padx=16, pady=(12, 8))
    ctk.CTkLabel(linha, text=planeta["name"], font=tema.fonte(22, negrito=True),
                 text_color=tema.TEXTO, wraplength=240, justify="left").pack(side="left")
    selo_planeta(linha, planeta["isDestroyed"]).pack(side="right")
    caixa = ctk.CTkTextbox(cartao, width=LARGURA_FOTO - 32, height=170, wrap="word",
                           font=tema.fonte(13), fg_color=tema.FUNDO, text_color=tema.TEXTO_SECUNDARIO)
    caixa.insert("1.0", planeta["description"])
    caixa.configure(state="disabled")
    caixa.pack(padx=16, pady=(0, 16))
    return cartao


def mostrar_planeta(planeta, imagem, moradores, fotos_moradores):
    """Card do planeta a esquerda; moradores (clicaveis) a direita."""
    janela = base.criar_janela(planeta["name"], 780, 600)
    criar_cartao_planeta(janela, planeta, imagem).grid(row=0, column=0, padx=20, pady=20, sticky="n")

    lado = ctk.CTkFrame(janela, fg_color="transparent")
    lado.grid(row=0, column=1, pady=20, sticky="n")
    ctk.CTkLabel(lado, text=f"👥 Moradores ({len(moradores)})", font=tema.fonte(16, negrito=True),
                 text_color=tema.DESTAQUE).pack(anchor="w")
    if not moradores:
        ctk.CTkLabel(lado, text="Nenhum personagem da API\nnasceu neste planeta.",
                     text_color=tema.TEXTO_SECUNDARIO, justify="left").pack(anchor="w", pady=10)
    else:
        rolagem = ctk.CTkScrollableFrame(lado, width=330, height=500, fg_color=tema.FUNDO)
        rolagem.pack()
        for posicao in range(len(moradores)):
            mini = MiniCartao(rolagem, moradores[posicao], fotos_moradores[posicao],
                              lambda personagem, foto: abrir_cartao(janela, personagem, foto))
            mini.grid(row=posicao // 2, column=posicao % 2, padx=6, pady=6, sticky="n")
    base.esperar_fechar(janela)


def mostrar_todos(planetas, fotos):
    """Grade com todos os planetas. Clicar abre o card do planeta."""
    janela = base.criar_janela("Planetas", 720, 640)
    ctk.CTkLabel(janela, text=f"🪐 {len(planetas)} planetas · clique para ver a descrição",
                 font=tema.fonte(16, negrito=True), text_color=tema.DESTAQUE).pack(pady=(14, 0))
    rolagem = ctk.CTkScrollableFrame(janela, fg_color=tema.FUNDO)
    rolagem.pack(fill="both", expand=True, padx=10, pady=10)
    for posicao in range(len(planetas)):
        planeta = planetas[posicao]
        situacao = "Destruído" if planeta["isDestroyed"] else "Preservado"
        mini = MiniCartao(rolagem, planeta, fotos[posicao],
                          lambda item, foto: abrir_cartao_planeta(janela, item, foto),
                          subtitulo=situacao)
        mini.grid(row=posicao // 4, column=posicao % 4, padx=8, pady=8, sticky="n")
    base.esperar_fechar(janela)


def abrir_cartao_planeta(mestre, planeta, imagem):
    filha = base.criar_janela(planeta["name"], 420, 560, mestre)
    criar_cartao_planeta(filha, planeta, imagem).pack(padx=20, pady=20)
