"""Janela da Opcao 2: grade de mini-cards com rolagem. Clicar abre o card completo."""

import customtkinter as ctk

from janelas import base, tema
from janelas.componentes import CartaoPersonagem, MiniCartao

COLUNAS = 4


def mostrar_grade(personagens, fotos):
    """Abre a grade e so volta quando ela for fechada."""
    janela = base.criar_janela("Resultados da busca", 720, 640)
    texto = f"{len(personagens)} personagens · clique num card para ver tudo"
    ctk.CTkLabel(janela, text=texto, font=tema.fonte(16, negrito=True),
                 text_color=tema.DESTAQUE).pack(pady=(14, 0))

    rolagem = ctk.CTkScrollableFrame(janela, fg_color=tema.FUNDO)
    rolagem.pack(fill="both", expand=True, padx=10, pady=10)
    for posicao in range(len(personagens)):
        linha = posicao // COLUNAS          # divisao inteira: 0,0,0,0,1,1,1,1,2...
        coluna = posicao % COLUNAS          # resto da divisao: 0,1,2,3,0,1,2,3,0...
        mini = MiniCartao(rolagem, personagens[posicao], fotos[posicao],
                          lambda personagem, foto: abrir_cartao(janela, personagem, foto))
        mini.grid(row=linha, column=coluna, padx=8, pady=8, sticky="n")
    base.esperar_fechar(janela)


def abrir_cartao(mestre, personagem, imagem):
    """Abre o card completo numa janela filha (ela fecha junto com a grade)."""
    filha = base.criar_janela(personagem["name"], 330, 620, mestre)
    CartaoPersonagem(filha, personagem, imagem).pack(padx=20, pady=20)
