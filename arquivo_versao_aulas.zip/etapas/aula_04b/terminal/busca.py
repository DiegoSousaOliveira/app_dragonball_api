"""Perguntar o nome de um personagem e encontra-lo, mesmo com erros de digitacao."""

from core import api
from terminal.menu import ler_numero, ler_sim_nao, mostrar_avisos

MAXIMO_NA_LISTA = 15


def escolher_da_lista(achados):
    """Varios personagens servem: mostra uma lista numerada e o usuario escolhe."""
    if len(achados) > MAXIMO_NA_LISTA:
        print(f"Encontrei {len(achados)} personagens. Digite um pedaco maior do nome.")
        return None
    print("Encontrei mais de um:")
    for numero, personagem in enumerate(achados, start=1):
        print(f"  {numero:>2} - {personagem['name']}")
    escolha = ler_numero("Qual deles? (numero, ou Enter para cancelar): ", 1, len(achados), padrao=0)
    if escolha == 0:
        return None
    return achados[escolha - 1]


def oferecer_sugestao(texto, personagens):
    """Nao achou nada: pergunta se era um nome parecido."""
    sugestao = api.sugerir_personagem(texto, personagens)
    if sugestao is not None:
        pergunta = f'Nao encontrei "{texto}". Voce quis dizer "{sugestao["name"]}"? (s/n): '
        if ler_sim_nao(pergunta):
            return sugestao
        return None
    print(f'Nao encontrei "{texto}".')
    return None


def escolher_personagem(pergunta="Nome do personagem: "):
    """Pergunta um nome e devolve o personagem (dicionario), ou None se nao achar."""
    personagens = api.listar_personagens()
    mostrar_avisos()
    texto = input(pergunta).strip()
    if not texto:
        return None
    achados = api.buscar_personagem(texto, personagens)
    if len(achados) == 1:
        return achados[0]
    if len(achados) > 1:
        return escolher_da_lista(achados)
    return oferecer_sugestao(texto, personagens)
