"""Uma funcao para cada opcao do menu. O main.py chama estas funcoes."""

from core import imagens
from janelas import personagem as janela_personagem
from terminal.busca import escolher_personagem


def em_construcao(nome):
    print(f"[em construcao] A opcao '{nome}' fica pronta numa proxima aula.")


def opcao_ver_personagem():
    personagem = escolher_personagem()
    if personagem is None:
        return
    print("Baixando imagem...")
    imagem = imagens.baixar_imagem(personagem["image"])
    print(f">> Abrindo a janela de {personagem['name']} (feche a janela para voltar ao menu)")
    janela_personagem.mostrar_personagem(personagem, imagem)


def opcao_buscar():
    em_construcao("Buscar personagens")


def opcao_batalha():
    em_construcao("Batalha")


def opcao_planetas():
    em_construcao("Planetas")


def opcao_ranking():
    em_construcao("Ranking de poder")


def opcao_quiz():
    em_construcao("Quem e esse personagem?")


def opcao_raio_x():
    em_construcao("Raio-X da API")
