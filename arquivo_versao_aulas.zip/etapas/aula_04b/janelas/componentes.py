"""Pecas reaproveitadas em varias janelas: o card do personagem e companhia."""

import customtkinter as ctk

from core import imagens
from janelas import tema

RAIO = 8          # arredondado dos cantos do card (igual a imagem de referencia)


def preparar_foto(imagem, largura, altura):
    """Monta a foto no tamanho certo, com os cantos de cima arredondados.
    Sem imagem (None): quadrado cinza escrito 'sem imagem'. Devolve (CTkImage, texto)."""
    if imagem is None:
        pronta = imagens.imagem_lisa(largura, altura, tema.SEM_FOTO)
        texto = "sem imagem"
    else:
        pronta = imagens.foto_de_card(imagem, largura, altura)
        texto = ""
    pronta = imagens.arredondar_cantos_de_cima(pronta, RAIO, tema.FUNDO)
    return ctk.CTkImage(light_image=pronta, dark_image=pronta, size=(largura, altura)), texto


class CartaoPersonagem(ctk.CTkFrame):
    """O card do personagem, igual ao do site da API: foto em cima, dados embaixo.

    Uma CLASSE e um molde. CartaoPersonagem(janela, goku, foto) cria UM card a partir do molde.
    'self' e o proprio card que esta sendo criado.
    """

    def __init__(self, mestre, personagem, imagem=None, largura=290, altura_foto=350):
        super().__init__(mestre, corner_radius=RAIO, fg_color=tema.CARD)
        self.largura = largura
        self.altura_foto = altura_foto
        self.foto = ctk.CTkLabel(self, text="", corner_radius=0, text_color=tema.TEXTO,
                                 font=tema.fonte(16, negrito=True))
        self.foto.pack()
        self.trocar_foto(imagem)
        self.criar_textos(personagem)

    def trocar_foto(self, imagem):
        """Coloca (ou troca) a foto do card."""
        # IMPORTANTE: guardar a imagem em self.imagem. Se ela ficar so numa variavel
        # local, o Python joga fora quando a funcao termina e a foto some da janela.
        self.imagem, texto = preparar_foto(imagem, self.largura, self.altura_foto)
        self.foto.configure(image=self.imagem, text=texto, compound="center")

    def criar_textos(self, personagem):
        """Nome, raca - genero e os tres pares rotulo/valor."""
        area = ctk.CTkFrame(self, fg_color="transparent")
        area.pack(fill="x", padx=16, pady=(10, 14))
        self.nome = self.texto(area, personagem["name"], 22, tema.TEXTO)
        self.texto(area, f"{personagem['race']} - {personagem['gender']}", 16, tema.DESTAQUE)
        self.par(area, "Base KI:", personagem["ki"])
        self.par(area, "Total KI:", personagem["maxKi"])
        self.par(area, "Affiliation:", personagem["affiliation"])

    def texto(self, area, conteudo, tamanho, cor, espaco_acima=0):
        rotulo = ctk.CTkLabel(area, text=conteudo, font=tema.fonte(tamanho, negrito=True),
                              text_color=cor, anchor="w", height=tamanho + 6,
                              wraplength=self.largura - 32, justify="left")
        rotulo.pack(fill="x", pady=(espaco_acima, 0))
        return rotulo

    def par(self, area, rotulo, valor):
        """Um rotulo branco pequeno ('Base KI:') e embaixo o valor amarelo maior."""
        self.texto(area, rotulo, 13, tema.TEXTO, espaco_acima=8)
        self.texto(area, valor, 17, tema.DESTAQUE)
