"""Janela da Opcao 1: mostra o card de um personagem."""

from janelas import base
from janelas.componentes import CartaoPersonagem


def mostrar_personagem(personagem, imagem):
    """Abre a janela com o card e so volta quando ela for fechada."""
    janela = base.criar_janela(personagem["name"], 330, 620)
    cartao = CartaoPersonagem(janela, personagem, imagem)
    cartao.pack(padx=20, pady=20)
    base.esperar_fechar(janela)
