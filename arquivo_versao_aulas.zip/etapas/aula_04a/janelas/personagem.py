"""Janela da Opcao 1: mostra um personagem."""

import customtkinter as ctk

from janelas import base, tema


def mostrar_personagem(personagem):
    """Abre a janela do personagem e so volta quando ela for fechada."""
    janela = base.criar_janela(personagem["name"], 420, 320)

    nome = ctk.CTkLabel(janela, text=personagem["name"], font=tema.fonte(28, negrito=True),
                        text_color=tema.DESTAQUE)
    nome.pack(pady=(30, 10))

    # Dentro da janela podemos usar acentos e emojis (no terminal, nao).
    texto = (f"Raça: {personagem['race']}\n"
             f"Gênero: {personagem['gender']}\n"
             f"Base KI: {personagem['ki']}\n"
             f"Total KI: {personagem['maxKi']}\n"
             f"Afiliação: {personagem['affiliation']}")
    dados = ctk.CTkLabel(janela, text=texto, font=tema.fonte(16), justify="left")
    dados.pack()

    fechar = tema.botao(janela, "Fechar", janela.destroy)
    fechar.pack(pady=20)

    base.esperar_fechar(janela)
