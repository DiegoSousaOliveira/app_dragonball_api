"""
Abrir janelas a partir do terminal.

Ideia: existe UMA janela-raiz escondida. Toda janela que o aluno ve e "filha" dela
(CTkToplevel). O terminal chama esperar_fechar(janela) e fica parado ate a janela fechar.
"""

import customtkinter as ctk

from janelas import tema

_raiz = None


def obter_raiz():
    """Cria UMA vez a janela-raiz escondida; todas as janelas do programa sao filhas dela."""
    global _raiz
    if _raiz is None:
        ctk.set_appearance_mode("dark")
        _raiz = ctk.CTk()
        _raiz.withdraw()              # esconde a raiz: o aluno so ve as janelas filhas
    return _raiz


def criar_janela(titulo, largura, altura):
    """Cria uma janela centralizada na tela e na frente do terminal."""
    janela = ctk.CTkToplevel(obter_raiz())
    janela.title(f"Dragon Ball Dex - {titulo}")
    janela.configure(fg_color=tema.FUNDO)
    # centraliza na tela
    x = (janela.winfo_screenwidth() - largura) // 2
    y = (janela.winfo_screenheight() - altura) // 2
    janela.geometry(f"{largura}x{altura}+{x}+{y}")
    # "topmost" coloca a janela acima de todas; depois de 300 ms tiramos isso,
    # senao ela ficaria grudada na frente de tudo para sempre
    janela.attributes("-topmost", True)
    janela.after(300, lambda: janela.attributes("-topmost", False))
    janela.focus_force()
    return janela


def esperar_fechar(janela):
    """Trava o terminal ate o aluno fechar a janela."""
    janela.wait_window()


def encerrar():
    """Chamar ao sair do programa."""
    global _raiz
    if _raiz is not None:
        _raiz.destroy()
        _raiz = None
