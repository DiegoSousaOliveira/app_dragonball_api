"""Tudo que desenha janelas (CustomTkinter) mora aqui."""
