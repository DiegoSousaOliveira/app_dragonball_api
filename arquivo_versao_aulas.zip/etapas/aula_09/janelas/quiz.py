"""Janela da Opcao 6: o jogo "Quem e esse personagem?"."""

import customtkinter as ctk

from core import imagens, quiz
from janelas import base, tema

LARGURA_FOTO = 300
ALTURA_FOTO = 360


class JanelaQuiz:
    """Guarda o estado do jogo: rodada atual, pontos, erros da rodada e se usou dica."""

    def __init__(self, rodadas, fotos):
        self.rodadas = rodadas
        self.fotos = fotos
        self.numero = 0                   # indice da rodada atual
        self.pontos = 0
        self.terminou = False
        self.janela = base.criar_janela("Quem é esse personagem?", 560, 630)
        self.criar_tela()
        self.comecar_rodada()

    # ---------------- montagem da tela ----------------

    def criar_tela(self):
        self.placar = ctk.CTkLabel(self.janela, text="", font=tema.fonte(15, negrito=True),
                                   text_color=tema.DESTAQUE)
        self.placar.pack(pady=(14, 6))
        self.foto = ctk.CTkLabel(self.janela, text="")
        self.foto.pack()
        self.dica = ctk.CTkLabel(self.janela, text="", text_color=tema.TEXTO_SECUNDARIO)
        self.dica.pack()
        self.mensagem = ctk.CTkLabel(self.janela, text="", font=tema.fonte(16, negrito=True))
        self.mensagem.pack(pady=(0, 6))
        grade = ctk.CTkFrame(self.janela, fg_color="transparent")
        grade.pack()
        self.botoes_opcao = []
        for indice in range(quiz.OPCOES_POR_RODADA):
            botao = self.criar_botao_opcao(grade, indice)
            botao.grid(row=indice // 2, column=indice % 2, padx=6, pady=4)
            self.botoes_opcao.append(botao)
        rodape = ctk.CTkFrame(self.janela, fg_color="transparent")
        rodape.pack(pady=10)
        self.botao_dica = tema.botao(rodape, "💡 Dica (-1 ponto)", self.dar_dica, largura=180)
        self.botao_dica.pack(side="left", padx=6)
        self.botao_proxima = tema.botao(rodape, "Próxima ▶", self.proxima_rodada, largura=180)
        self.botao_proxima.pack(side="left", padx=6)

    def criar_botao_opcao(self, mestre, indice):
        """Cada botao lembra o SEU indice (0, 1, 2 ou 3) e o entrega para responder()."""
        return tema.botao(mestre, "", lambda: self.responder(indice), largura=240)

    # ---------------- andamento do jogo ----------------

    def comecar_rodada(self):
        rodada = self.rodadas[self.numero]
        self.erros = 0
        self.usou_dica = False
        self.rodada_acabou = False
        foto = self.fotos[self.numero]
        if foto is None:
            self.foto_base = imagens.imagem_lisa(LARGURA_FOTO, ALTURA_FOTO, tema.SEM_FOTO)
        else:
            self.foto_base = imagens.foto_de_card(foto, LARGURA_FOTO, ALTURA_FOTO)
        for indice in range(quiz.OPCOES_POR_RODADA):
            self.botoes_opcao[indice].configure(text=rodada["opcoes"][indice]["name"],
                                                state="normal", fg_color=tema.DESTAQUE)
        self.dica.configure(text="")
        self.mensagem.configure(text="Quem é esse personagem?", text_color=tema.TEXTO)
        self.botao_dica.configure(state="normal")
        self.botao_proxima.configure(state="disabled", text="Próxima ▶")
        self.mostrar_foto()
        self.atualizar_placar()

    def mostrar_foto(self):
        """Pixelada conforme os erros; nitida quando a rodada acaba."""
        nivel = None if self.rodada_acabou else quiz.nivel_de_pixel(self.erros)
        pronta = self.foto_base if nivel is None else imagens.pixelar(self.foto_base, nivel)
        self.imagem = ctk.CTkImage(light_image=pronta, dark_image=pronta, size=(LARGURA_FOTO, ALTURA_FOTO))
        self.foto.configure(image=self.imagem)

    def responder(self, indice):
        rodada = self.rodadas[self.numero]
        escolhido = rodada["opcoes"][indice]
        botao = self.botoes_opcao[indice]
        if escolhido["id"] == rodada["resposta"]["id"]:
            ganhou = quiz.premio(self.erros, self.usou_dica)
            self.pontos += ganhou
            botao.configure(fg_color=tema.SUCESSO)
            self.mensagem.configure(text=f"Acertou! É {escolhido['name']}. +{ganhou} ponto(s)",
                                    text_color=tema.SUCESSO)
            self.terminar_rodada()
        else:
            self.erros += 1
            botao.configure(state="disabled", fg_color=tema.PERIGO)
            self.mensagem.configure(text="Errou! A imagem ficou mais nítida...", text_color=tema.PERIGO)
            self.mostrar_foto()
        self.atualizar_placar()

    def dar_dica(self):
        resposta = self.rodadas[self.numero]["resposta"]
        self.usou_dica = True
        self.dica.configure(text=f"💡 Raça: {resposta['race']}  ·  Afiliação: {resposta['affiliation']}")
        self.botao_dica.configure(state="disabled")
        self.atualizar_placar()

    def terminar_rodada(self):
        self.rodada_acabou = True
        for botao in self.botoes_opcao:
            botao.configure(state="disabled")
        self.botao_dica.configure(state="disabled")
        self.mostrar_foto()
        if self.numero == len(self.rodadas) - 1:
            self.botao_proxima.configure(state="normal", text="Ver resultado 🏁")
        else:
            self.botao_proxima.configure(state="normal")

    def proxima_rodada(self):
        self.numero += 1
        if self.numero < len(self.rodadas):
            self.comecar_rodada()
        else:
            self.fim_de_jogo()

    def fim_de_jogo(self):
        self.terminou = True
        maximo = len(self.rodadas) * quiz.PREMIO_INICIAL
        self.mensagem.configure(text=f"Fim de jogo! {self.pontos} de {maximo} pontos. Feche a janela.",
                                text_color=tema.DESTAQUE)
        self.botao_proxima.configure(state="disabled")

    def atualizar_placar(self):
        vale = 0 if self.rodada_acabou else quiz.premio(self.erros, self.usou_dica)
        self.placar.configure(text=f"Rodada {self.numero + 1} de {len(self.rodadas)}   ·   "
                                   f"Pontos: {self.pontos}   ·   Esta rodada vale: {vale}")


def jogar(rodadas, fotos):
    """Abre o jogo. Devolve os pontos, ou None se a janela foi fechada antes do fim."""
    tela = JanelaQuiz(rodadas, fotos)
    base.esperar_fechar(tela.janela)
    if tela.terminou:
        return tela.pontos
    return None
