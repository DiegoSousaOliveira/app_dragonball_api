#!/bin/sh
# Dragon Ball Dex - para abrir no Linux/Mac:  sh iniciar.sh
cd "$(dirname "$0")"
if [ -x ".venv/bin/python" ]; then
    .venv/bin/python main.py "$@"
else
    python3 main.py "$@"
fi
