@echo off
REM Dragon Ball Dex - clique duas vezes para abrir (Windows)
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" main.py %*
) else (
    python main.py %*
)
pause
