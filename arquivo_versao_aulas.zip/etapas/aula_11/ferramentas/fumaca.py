"""
Teste de fumaca: abre CADA janela do programa com dados reais e fecha sozinha depois de 1,5 s.
Se alguma janela der erro, aparece [FALHA] com a explicacao.

    python main.py --fumaca

("Teste de fumaca" vem da eletronica: liga o aparelho e ve se sai fumaca.)
"""

import random
import traceback

from core import api, filtros, imagens, quiz
from janelas import base, tema
from janelas import batalha as janela_batalha
from janelas import grade, grafico_latencia, planeta, ranking
from janelas import personagem as janela_personagem
from janelas import quiz as janela_quiz

ESPERA = 1500
erros_nas_janelas = []


def esperar_e_fechar(janela):
    """Substitui base.esperar_fechar: agenda o fechamento e espera."""
    janela.after(ESPERA, lambda: janela.winfo_exists() and janela.destroy())
    janela.wait_window()


def anotar_erro(tipo, valor, rastro):
    """Erros que acontecem DENTRO da janela (num clique, num after) caem aqui."""
    erros_nas_janelas.append(valor)
    traceback.print_exception(tipo, valor, rastro)


def fotos_de(itens):
    return [imagens.baixar_imagem(item["image"]) for item in itens]


def testar_personagem():
    goku = api.detalhar_personagem(1)
    fotos = fotos_de(goku["transformations"])
    carrossel = janela_personagem.Carrossel(base.obter_raiz(), goku["transformations"], fotos)
    carrossel.proxima()
    base.esperar_fechar(carrossel.janela)
    janela_personagem.mostrar_personagem(goku, imagens.baixar_imagem(goku["image"]), fotos)


def testar_grade():
    saiyans = filtros.filtrar(api.listar_personagens(), raca="Saiyan")
    grade.mostrar_grade(saiyans, fotos_de(saiyans))


def testar_batalha():
    goku, bulma = api.detalhar_personagem(1), api.detalhar_personagem(4)
    tela = janela_batalha.JanelaBatalha(goku, bulma, fotos_de([goku, bulma]), [None, None], "maxKi")
    tela.transformar("a")
    tela.lutar()
    base.esperar_fechar(tela.janela)
    tela.fechar()                       # fecha com uma rodada ainda agendada: nao pode dar erro


def testar_planetas():
    namek = api.detalhar_planeta(1)
    planeta.mostrar_planeta(namek, imagens.baixar_imagem(namek["image"]), namek["characters"],
                            fotos_de(namek["characters"]))
    todos = api.listar_planetas()
    planeta.mostrar_todos(todos, fotos_de(todos))


def testar_ranking():
    lista, ignorados = filtros.montar_ranking(api.listar_personagens(), "maxKi", 10)
    ranking.mostrar_ranking("Top 10", lista, fotos_de([p for p, ki in lista]), ignorados)


def testar_quiz():
    rodadas = quiz.montar_rodadas(api.listar_personagens(), 3, random.Random(1))
    tela = janela_quiz.JanelaQuiz(rodadas, fotos_de([r["resposta"] for r in rodadas]))
    for indice in range(4):
        tela.responder(indice)          # erra ate acertar
        if tela.rodada_acabou:
            break
    tela.dar_dica()
    base.esperar_fechar(tela.janela)


def testar_grafico():
    grafico_latencia.mostrar_grafico("Fumaça", [("A", [600, 620, 610], tema.PERIGO),
                                                ("B", [600, 200, 210], tema.SUCESSO)])


TESTES = [("Ver personagem + carrossel", testar_personagem), ("Grade da busca", testar_grade),
          ("Batalha", testar_batalha), ("Planetas", testar_planetas), ("Ranking", testar_ranking),
          ("Quiz", testar_quiz), ("Grafico de latencia", testar_grafico)]


def rodar():
    base.esperar_fechar = esperar_e_fechar        # troca a funcao: as janelas fecham sozinhas
    base.obter_raiz().report_callback_exception = anotar_erro
    falhas = 0
    for nome, teste in TESTES:
        antes = len(erros_nas_janelas)
        try:
            teste()
        except Exception:
            traceback.print_exc()
            falhas += 1
            print(f"[FALHA] {nome}")
            continue
        if len(erros_nas_janelas) > antes:
            falhas += 1
            print(f"[FALHA] {nome} (erro dentro da janela)")
        else:
            print(f"[OK]    {nome}")
    print(f"Teste de fumaca terminado: {len(TESTES) - falhas} ok, {falhas} com falha.")
    return falhas
