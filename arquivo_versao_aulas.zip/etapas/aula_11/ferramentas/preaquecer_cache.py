"""
Pre-aquecer o cache: baixa TODOS os dados e TODAS as imagens para a pasta cache/.

Ferramenta do professor. Rode EM CASA, com internet boa:
    python ferramentas/preaquecer_cache.py
Depois copie a pasta cache/ para o pendrive e cole na pasta do projeto no laboratorio.
Assim os 30 computadores nao precisam baixar as mesmas imagens ao mesmo tempo.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import api, imagens
from core.armazenamento import PASTA_CACHE


def baixar_lista(urls, descricao):
    falhas = 0
    for numero, url in enumerate(urls, start=1):
        if imagens.baixar_imagem(url) is None:
            falhas += 1
        print(f"\r  {descricao}: {numero}/{len(urls)}", end="")
    print(f"  ({falhas} falharam)" if falhas else "  [OK]")


def principal():
    api.limpar_cache()                       # comeca do zero: dados fresquinhos
    print("Baixando dados...")
    personagens = [api.detalhar_personagem(p["id"]) for p in api.listar_personagens()]
    planetas = [api.detalhar_planeta(p["id"]) for p in api.listar_planetas()]
    print(f"  {len(personagens)} personagens e {len(planetas)} planetas")
    transformacoes = [t for p in personagens for t in p["transformations"]]
    print("Baixando imagens...")
    baixar_lista([p["image"] for p in personagens], "personagens")
    baixar_lista([t["image"] for t in transformacoes], "transformacoes")
    baixar_lista([p["image"] for p in planetas], "planetas")
    tamanho = sum(arquivo.stat().st_size for arquivo in PASTA_CACHE.rglob("*") if arquivo.is_file())
    print(f"Pronto! A pasta {PASTA_CACHE} tem {tamanho / 1024 / 1024:.1f} MB.")
    print("Copie essa pasta para o pendrive. O cache vale 24 h para os dados (depois o programa")
    print("tenta atualizar, mas se nao houver internet continua usando o que ja tem).")


if __name__ == "__main__":
    principal()
