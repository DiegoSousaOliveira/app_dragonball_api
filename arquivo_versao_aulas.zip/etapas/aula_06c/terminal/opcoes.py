"""Uma funcao para cada opcao do menu. O main.py chama estas funcoes."""

from datetime import datetime

from core import api, batalha, imagens
from core import filtros as filtros_core
from core.armazenamento import PASTA_DADOS, carregar_json, salvar_json
from janelas import batalha as janela_batalha
from janelas import grade as janela_grade
from janelas import personagem as janela_personagem
from terminal.busca import escolher_personagem
from terminal.menu import (LARGURA, escolher_de_lista, ler_numero, ler_sim_nao, mostrar_avisos,
                           mostrar_progresso)

LIMITE_DA_GRADE = 20            # mais que isso deixaria a janela lenta e cheia demais
ARQUIVO_HISTORICO = PASTA_DADOS / "historico.json"


def em_construcao(nome):
    print(f"[em construcao] A opcao '{nome}' fica pronta numa proxima aula.")


def baixar_imagens(urls, descricao):
    """Baixa varias imagens mostrando uma barra de progresso. Devolve a lista de imagens."""
    fotos = []
    for numero, url in enumerate(urls, start=1):
        fotos.append(imagens.baixar_imagem(url))
        mostrar_progresso(f"Baixando {descricao}", numero, len(urls))
    return fotos


def abrindo(nome):
    print(f">> Abrindo a janela de {nome} (feche a janela para voltar ao menu)")


def opcao_ver_personagem():
    personagem = escolher_personagem()
    if personagem is None:
        return
    print("Buscando detalhes...")
    detalhe = api.detalhar_personagem(personagem["id"])
    mostrar_avisos()
    print("Baixando imagem...")
    imagem = imagens.baixar_imagem(detalhe["image"])
    urls = []
    for transformacao in detalhe["transformations"]:
        urls.append(transformacao["image"])
    fotos = baixar_imagens(urls, "transformacoes")
    abrindo(detalhe["name"])
    janela_personagem.mostrar_personagem(detalhe, imagem, fotos)


def perguntar_filtros(personagens):
    """Faz as perguntas da busca. Todas sao opcionais (Enter pula)."""
    print("Preencha os filtros (Enter pula):")
    filtros = {
        "nome": input("Nome contem: ").strip(),
        "raca": escolher_de_lista("Raca", filtros_core.valores_unicos(personagens, "race")),
        "afiliacao": escolher_de_lista("Afiliacao", filtros_core.valores_unicos(personagens, "affiliation")),
        "genero": escolher_de_lista("Genero", filtros_core.valores_unicos(personagens, "gender")),
    }
    ordem = ler_numero("Ordenar por: 1 - Nome  2 - Base KI  3 - Total KI (Enter = nome): ", 1, 3, padrao=1)
    criterios = {1: "nome", 2: "ki", 3: "maxKi"}
    return filtros, criterios[ordem]


def mostrar_tabela(achados, total):
    """Imprime os personagens alinhados em colunas."""
    print()
    print(f"{'Nome':<24}{'Raca':<18}{'Base KI':>16}{'Total KI':>20}")
    print("-" * 78)
    for p in achados:
        print(f"{p['name']:<24}{p['race']:<18}{p['ki']:>16}{p['maxKi']:>20}")
    print("-" * 78)
    if not achados:
        print("Nenhum personagem combina com esses filtros.")
    print(f"{len(achados)} de {total} personagens")


def opcao_buscar():
    personagens = api.listar_personagens()
    mostrar_avisos()
    filtros, criterio = perguntar_filtros(personagens)
    achados = filtros_core.filtrar(personagens, filtros["nome"], filtros["raca"],
                                   filtros["afiliacao"], filtros["genero"])
    achados = filtros_core.ordenar(achados, criterio)
    mostrar_tabela(achados, len(personagens))
    if not achados:
        return
    if len(achados) > LIMITE_DA_GRADE:
        print(f"Mostrando {LIMITE_DA_GRADE} de {len(achados)}; refine o filtro para ver os outros.")
        achados = achados[:LIMITE_DA_GRADE]
    fotos = baixar_imagens([p["image"] for p in achados], "imagens")
    abrindo("resultados da busca")
    janela_grade.mostrar_grade(achados, fotos)


def escolher_lutadores():
    """Pergunta os dois lutadores e a metrica. Devolve (lutador1, lutador2, metrica) ou None."""
    print("Escolha os lutadores (digite 'aleatorio' para sortear).")
    primeiro = escolher_personagem("Lutador 1: ")
    if primeiro is None:
        return None
    segundo = escolher_personagem("Lutador 2: ")
    if segundo is None:
        return None
    escolha = ler_numero("Poder: 1 - Base KI  2 - Total KI (Enter = Total KI): ", 1, 2, padrao=2)
    metrica = "ki" if escolha == 1 else "maxKi"
    return primeiro, segundo, metrica


def mostrar_resultado(resultado):
    print("=" * LARGURA)
    print(f"VENCEDOR: {resultado['vencedor']}".center(LARGURA))
    print("=" * LARGURA)
    print(f"Rodadas: {resultado['rodadas']}")
    for nome, dano in resultado["dano"].items():
        print(f"Dano causado por {nome}: {dano}")


def foto_da_transformacao(personagem):
    """URL da imagem da transformacao mais forte (a ultima), ou None se nao houver."""
    if personagem["transformations"]:
        return personagem["transformations"][-1]["image"]
    return None


def registrar_no_historico(resultado, metrica):
    historico = carregar_json(ARQUIVO_HISTORICO, padrao=[])
    historico.append({
        "data": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "vencedor": resultado["vencedor"],
        "perdedor": resultado["perdedor"],
        "rodadas": resultado["rodadas"],
        "metrica": metrica,
    })
    salvar_json(ARQUIVO_HISTORICO, historico)


def mostrar_hall_da_fama():
    ranking = batalha.contar_vitorias(carregar_json(ARQUIVO_HISTORICO, padrao=[]))
    print("-" * LARGURA)
    print("HALL DA FAMA".center(LARGURA))
    print("-" * LARGURA)
    for posicao, (nome, vitorias) in enumerate(ranking[:5], start=1):
        print(f"{posicao:>2}. {nome:<25}{vitorias:>3} vitoria(s)")


def opcao_batalha():
    escolhidos = escolher_lutadores()
    if escolhidos is None:
        return
    primeiro, segundo, metrica = escolhidos
    print("Buscando detalhes (transformacoes)...")
    primeiro = api.detalhar_personagem(primeiro["id"])
    segundo = api.detalhar_personagem(segundo["id"])
    mostrar_avisos()
    urls = [primeiro["image"], segundo["image"],
            foto_da_transformacao(primeiro), foto_da_transformacao(segundo)]
    fotos = baixar_imagens(urls, "imagens")
    while True:
        abrindo("batalha")
        resultado = janela_batalha.mostrar_batalha(primeiro, segundo, fotos[:2], fotos[2:], metrica)
        if resultado is None:
            print("A janela foi fechada antes do fim da luta.")
            break
        mostrar_resultado(resultado)
        registrar_no_historico(resultado, metrica)
        if not ler_sim_nao("Revanche? (s/n): "):
            break
    mostrar_hall_da_fama()


def opcao_planetas():
    em_construcao("Planetas")


def opcao_ranking():
    em_construcao("Ranking de poder")


def opcao_quiz():
    em_construcao("Quem e esse personagem?")


def opcao_raio_x():
    em_construcao("Raio-X da API")
