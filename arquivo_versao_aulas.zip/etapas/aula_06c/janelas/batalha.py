"""Janela da Opcao 3: dois cards frente a frente, barras de vida e a narracao da luta."""

import customtkinter as ctk

from core import batalha
from janelas import base, tema
from janelas.componentes import BarraDeVida, CartaoPersonagem

PAUSA_ENTRE_RODADAS = 900        # milissegundos


class JanelaBatalha:
    """Guarda a luta e os pedacos da janela que mudam (barras, narracao, botoes)."""

    def __init__(self, personagem_a, personagem_b, fotos, fotos_transformacao, metrica):
        self.luta = batalha.iniciar_luta(personagem_a, personagem_b, metrica)
        self.resultado = None            # fica preenchido quando a luta acabar
        self.agendado = None             # a proxima rodada que o after() marcou
        titulo = f"{personagem_a['name']} x {personagem_b['name']}"
        self.janela = base.criar_janela(titulo, 820, 600)
        # Fechar pelo X tambem passa pela nossa funcao fechar()
        self.janela.protocol("WM_DELETE_WINDOW", self.fechar)
        self.barras = {}
        self.cartoes = {}
        self.botoes_transformar = {}
        self.fotos_transformacao = {"a": fotos_transformacao[0], "b": fotos_transformacao[1]}
        self.criar_lado("a", personagem_a, fotos[0], coluna=0)
        self.criar_centro()
        self.criar_lado("b", personagem_b, fotos[1], coluna=2)

    def criar_lado(self, lado, personagem, foto, coluna):
        """Um card pequeno, a barra de vida e (se der) o botao Transformar."""
        coluna_frame = ctk.CTkFrame(self.janela, fg_color="transparent")
        coluna_frame.grid(row=0, column=coluna, padx=16, pady=16, sticky="n")
        self.cartoes[lado] = CartaoPersonagem(coluna_frame, personagem, foto, largura=210, altura_foto=230)
        self.cartoes[lado].pack()
        self.barras[lado] = BarraDeVida(coluna_frame, largura=210)
        self.barras[lado].pack(pady=(10, 0))
        if batalha.pode_transformar(self.luta[lado]):
            botao = tema.botao(coluna_frame, "Transformar! ⚡", lambda: self.transformar(lado))
            botao.pack(pady=(10, 0))
            self.botoes_transformar[lado] = botao

    def criar_centro(self):
        """No meio: o 'VS', a caixa de narracao e os botoes."""
        centro = ctk.CTkFrame(self.janela, fg_color="transparent")
        centro.grid(row=0, column=1, pady=16, sticky="n")
        ctk.CTkLabel(centro, text="VS", font=tema.fonte(36, negrito=True),
                     text_color=tema.DESTAQUE).pack()
        self.narracao = ctk.CTkTextbox(centro, width=300, height=380, wrap="word",
                                       font=tema.fonte(13), fg_color=tema.CARD)
        self.narracao.pack(pady=10)
        self.botao_lutar = tema.botao(centro, "Lutar! 👊", self.lutar)
        self.botao_lutar.pack(pady=(0, 8))
        tema.botao(centro, "Fechar", self.fechar).pack()

    def escrever(self, frase):
        """Acrescenta uma linha na narracao e rola para o fim."""
        self.narracao.insert("end", frase + "\n\n")
        self.narracao.see("end")

    def atualizar_barras(self):
        self.barras["a"].atualizar(self.luta["a"]["hp"])
        self.barras["b"].atualizar(self.luta["b"]["hp"])

    def lutar(self):
        """Versao 2 (Aula 6C): comeca a luta; cada rodada agenda a seguinte."""
        self.botao_lutar.configure(state="disabled")
        self.proxima_rodada()

    def proxima_rodada(self):
        """UMA rodada. Depois pede ao after() para chamar esta funcao de novo daqui a 900 ms.
        (Com time.sleep a janela congelaria: ela nao conseguiria se redesenhar durante a espera.)"""
        if batalha.luta_acabou(self.luta):
            self.terminar()
            return
        self.escrever(batalha.jogar_rodada(self.luta))
        self.atualizar_barras()
        self.agendado = self.janela.after(PAUSA_ENTRE_RODADAS, self.proxima_rodada)

    def transformar(self, lado):
        """Usa a transformacao (1 vez por luta): troca a foto e da forca x1.5 por 3 rodadas."""
        lutador = self.luta[lado]
        if not batalha.pode_transformar(lutador):
            return
        transformacao = batalha.transformar(lutador)
        foto = self.fotos_transformacao[lado]
        if foto is not None:
            self.cartoes[lado].trocar_foto(foto)
        self.cartoes[lado].nome.configure(text=transformacao["name"])
        self.botoes_transformar[lado].configure(state="disabled")
        self.escrever(f"⚡ {lutador['nome']} se transformou em {transformacao['name']}! "
                      f"Forca x{batalha.BONUS_TRANSFORMACAO} por {batalha.RODADAS_TRANSFORMADO} rodadas!")

    def terminar(self):
        self.agendado = None
        self.resultado = batalha.resultado(self.luta)
        self.escrever(f"🏆 {self.resultado['vencedor']} venceu em {self.resultado['rodadas']} rodadas!")
        for botao in self.botoes_transformar.values():
            botao.configure(state="disabled")

    def fechar(self):
        """Cancela a rodada agendada ANTES de fechar. Sem isso, o after() tentaria mexer
        numa janela que nao existe mais (erro 'invalid command name')."""
        if self.agendado is not None:
            self.janela.after_cancel(self.agendado)
        self.janela.destroy()


def mostrar_batalha(personagem_a, personagem_b, fotos, fotos_transformacao, metrica):
    """Abre a janela da luta. Quando ela fecha, devolve o resultado (ou None se nao terminou)."""
    tela = JanelaBatalha(personagem_a, personagem_b, fotos, fotos_transformacao, metrica)
    base.esperar_fechar(tela.janela)
    return tela.resultado
