"""
Ferramentas do laboratorio de Redes (Opcao 7 - Raio-X da API).
Aqui so medimos e devolvemos numeros; quem mostra e explica e o terminal/raio_x.py.
"""

import socket
import time

import requests

from core import api

HOST = "dragonball-api.com"


def anotar(resposta, ms):
    """Coloca a requisicao no log da sessao (o mesmo que a opcao 'Log' mostra)."""
    tipo = resposta.headers.get("Content-Type", "-")
    api.registrar(resposta.url, resposta.status_code, round(ms), len(resposta.content), tipo, "rede")


def requisicao_crua(caminho, params=None, timeout=api.TIMEOUT):
    """GET direto, SEM cache e sem esconder erros: para ver a resposta exatamente como ela vem.
    Erros de rede (sem internet, timeout) sobem como excecoes do requests."""
    inicio = time.perf_counter()
    resposta = requests.get(api.URL_BASE + caminho, params=params, headers=api.CABECALHOS, timeout=timeout)
    anotar(resposta, (time.perf_counter() - inicio) * 1000)
    return resposta


def medir_latencias(quantas, caminho="/planets", usar_sessao=False):
    """Faz 'quantas' requisicoes seguidas e devolve os tempos em milissegundos.
    usar_sessao=False: cada requests.get abre uma conexao NOVA (DNS + TCP + TLS toda vez).
    usar_sessao=True: a Session reaproveita a mesma conexao (keep-alive)."""
    sessao = requests.Session()
    sessao.headers.update(api.CABECALHOS)
    tempos = []
    for _ in range(quantas):
        inicio = time.perf_counter()
        if usar_sessao:
            resposta = sessao.get(api.URL_BASE + caminho, timeout=api.TIMEOUT)
        else:
            resposta = requests.get(api.URL_BASE + caminho, headers=api.CABECALHOS, timeout=api.TIMEOUT)
        ms = (time.perf_counter() - inicio) * 1000
        anotar(resposta, ms)
        tempos.append(ms)
    sessao.close()
    return tempos


def resumo(tempos):
    """(minimo, media, maximo) de uma lista de tempos."""
    return min(tempos), sum(tempos) / len(tempos), max(tempos)


def descobrir_ip(host=HOST):
    """Pergunta ao DNS qual e o endereco IP do site. Devolve (ip, milissegundos)."""
    inicio = time.perf_counter()
    ip = socket.gethostbyname(host)
    return ip, (time.perf_counter() - inicio) * 1000


def provocar_timeout(segundos=0.001):
    """Pede uma resposta em 1 milissegundo (impossivel!). Devolve o nome do erro que acontece."""
    try:
        requests.get(api.URL_BASE + "/characters", headers=api.CABECALHOS, timeout=segundos)
    except requests.RequestException as erro:
        return type(erro).__name__
    return "nenhum erro (a internet esta MUITO rapida!)"
