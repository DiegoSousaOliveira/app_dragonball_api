"""
Opcao 7 - Raio-X da API: o laboratorio de Redes.
Mostra o que acontece "por baixo" quando o programa conversa com a API.
"""

import json

import requests

from core import api, rede
from terminal.menu import LARGURA, ler_numero, ler_opcao, titulo

ITENS = [
    "1 - Log de requisicoes desta sessao",
    "2 - Testador de requisicao",
    "3 - Medidor de latencia",
    "4 - DNS e conexao",
    "5 - Experimentos (erros, timeout, offline)",
    "0 - Voltar ao menu principal",
]


def caminho_curto(url):
    """'https://dragonball-api.com/api/planets?limit=100' -> '/planets?limit=100'."""
    return url.replace(api.URL_BASE, "")


# ----------------------------------------------------------------------
# 1 - Log de requisicoes
# ----------------------------------------------------------------------

def mostrar_log():
    log = api.LOG_REQUISICOES
    if not log:
        print("Nenhuma requisicao ainda. Use outras opcoes e volte aqui!")
        return
    print(f"{'hora':<9}{'origem':<7}{'status':>6}{'ms':>7}{'bytes':>9}  {'tipo':<20}url")
    for item in log[-25:]:                      # as 25 mais recentes
        tipo = item["content_type"].split(";")[0]
        print(f"{item['hora']:<9}{item['origem']:<7}{item['status']:>6}{item['ms']:>7}"
              f"{item['bytes']:>9}  {tipo:<20}{caminho_curto(item['url'])[:60]}")
    da_rede = [item for item in log if item["origem"] == "rede"]
    total_bytes = sum(item["bytes"] for item in da_rede)
    print("-" * LARGURA)
    print(f"{len(log)} requisicoes: {len(da_rede)} pela rede, {len(log) - len(da_rede)} do cache.")
    print(f"Bytes recebidos pela rede: {total_bytes:,}".replace(",", "."))


# ----------------------------------------------------------------------
# 2 - Testador de requisicao
# ----------------------------------------------------------------------

ENDPOINTS = ["/characters", "/planets", "/transformations", "/characters/{id}", "/planets/{id}"]


def montar_pedido():
    """Pergunta o endpoint e os parametros. Devolve (caminho, params)."""
    for numero, endpoint in enumerate(ENDPOINTS, start=1):
        print(f"  {numero} - {endpoint}")
    escolha = ler_numero("Endpoint: ", 1, len(ENDPOINTS))
    caminho = ENDPOINTS[escolha - 1]
    params = {}
    if "{id}" in caminho:
        identificador = input("id (tente 1, 99999 ou abc): ").strip() or "1"
        caminho = caminho.replace("{id}", identificador)
    else:
        print("Parametros (Enter pula):")
        for nome in ("page", "limit", "name", "race"):
            valor = input(f"  {nome} = ").strip()
            if valor:
                params[nome] = valor
    return caminho, params


def mostrar_resposta(resposta):
    print(f"URL final montada: {resposta.url}")
    print(f"Status: {resposta.status_code} {resposta.reason}")
    print(f"Tempo ate a resposta: {resposta.elapsed.total_seconds() * 1000:.0f} ms")
    print(f"Tamanho: {len(resposta.content)} bytes")
    print("Cabecalhos da resposta:")
    for nome, valor in resposta.headers.items():
        print(f"  {nome}: {valor}")
    try:
        texto = json.dumps(resposta.json(), indent=2, ensure_ascii=False)
    except ValueError:
        texto = resposta.text or "(corpo vazio)"
    print("Corpo (primeiros 800 caracteres):")
    print(texto[:800])


def testar_requisicao():
    caminho, params = montar_pedido()
    try:
        resposta = rede.requisicao_crua(caminho, params)
    except requests.RequestException as erro:
        print(f"[ERRO DE REDE] {type(erro).__name__}: nao houve resposta.")
        return
    mostrar_resposta(resposta)


# ----------------------------------------------------------------------
# 3 - Medidor de latencia
# ----------------------------------------------------------------------

def imprimir_tempos(tempos):
    for numero, ms in enumerate(tempos, start=1):
        print(f"  {numero:>2}: {ms:7.0f} ms  " + "#" * int(ms // 50))
    minimo, media, maximo = rede.resumo(tempos)
    print(f"  minimo {minimo:.0f} ms | media {media:.0f} ms | maximo {maximo:.0f} ms")


def medir_latencia():
    print("Fazendo 5 requisicoes seguidas para /planets (sem cache)...")
    tempos = rede.medir_latencias(5)
    imprimir_tempos(tempos)
    print("Latencia = tempo de ida e volta. Ela muda a cada vez: a rede e compartilhada!")


# ----------------------------------------------------------------------
# 4 - DNS e conexao
# ----------------------------------------------------------------------

def mostrar_dns():
    ip, ms = rede.descobrir_ip()
    print(f"Nome:  {rede.HOST}")
    print(f"IP:    {ip}   (o DNS respondeu em {ms:.0f} ms)")
    print("Porta: 443 (HTTPS = HTTP protegido por TLS)")
    print()
    print("O caminho de cada requisicao:")
    print("  1. DNS: 'qual o IP de dragonball-api.com?' -> " + ip)
    print("  2. TCP: aperto de maos em 3 passos com o servidor (SYN, SYN-ACK, ACK)")
    print("  3. TLS: combinam a criptografia (o cadeado do navegador)")
    print("  4. HTTP: enviamos 'GET /api/characters'")
    print("  5. Resposta: status 200 + cabecalhos + o JSON")
    print("Com Session, os passos 1 a 3 acontecem so na primeira vez.")


# ----------------------------------------------------------------------
# 5 - Experimentos
# ----------------------------------------------------------------------

ERROS_DE_PROPOSITO = [
    ("ID que nao existe", "/characters/99999"),
    ("Rota que nao existe", "/rota-que-nao-existe"),
    ("ID que nem e numero", "/characters/abc"),
    ("Transformacao que nao existe", "/transformations/999"),
]


def erros_de_proposito():
    for descricao, caminho in ERROS_DE_PROPOSITO:
        try:
            resposta = rede.requisicao_crua(caminho)
        except requests.RequestException as erro:
            print(f"{descricao}: erro de rede {type(erro).__name__}")
            continue
        corpo = resposta.text[:90] or "(corpo vazio!)"
        print(f"{descricao:<30} {caminho:<22} -> {resposta.status_code} {resposta.reason}")
        print(f"    {corpo}")
    print("4xx = o PEDIDO tem problema (culpa do cliente). 5xx = o SERVIDOR quebrou.")
    print("Repare: a API responde 400 (e nao 404) para id inexistente, e 200 com corpo vazio")
    print("para transformacao inexistente. APIs reais nem sempre seguem o livro!")


def experimentos():
    print("  1 - Erros de proposito (400, 404, 500 e um 200 vazio)")
    print("  2 - Timeout (pedir resposta em 0,001 segundo)")
    estado = "LIGADO" if api.modo_offline else "desligado"
    print(f"  3 - Modo offline (agora: {estado})")
    escolha = ler_numero("Experimento: ", 1, 3)
    if escolha == 1:
        erros_de_proposito()
    elif escolha == 2:
        print("Erro recebido:", rede.provocar_timeout())
        print("Timeout = tempo maximo de espera. Sem ele, um programa pode esperar PARA SEMPRE.")
    else:
        api.modo_offline = not api.modo_offline
        if api.modo_offline:
            print("Modo offline LIGADO. Volte ao menu e use as opcoes 1 a 6: o programa vai usar")
            print("so o cache e os dados salvos, como se o cabo de rede estivesse desligado.")
        else:
            print("Modo offline desligado: o programa voltou a usar a internet.")


# ----------------------------------------------------------------------
# Submenu
# ----------------------------------------------------------------------

ACOES = {1: mostrar_log, 2: testar_requisicao, 3: medir_latencia, 4: mostrar_dns, 5: experimentos}


def menu_raio_x():
    while True:
        print()
        titulo("RAIO-X DA API")
        for item in ITENS:
            print("    " + item)
        opcao = ler_opcao(list(ACOES) + [0])
        if opcao == 0:
            return
        try:
            ACOES[opcao]()
        except (OSError, requests.RequestException) as erro:   # sem internet, DNS falhou...
            print(f"[ERRO DE REDE] {type(erro).__name__}: verifique a conexao.")
