"""Uma funcao para cada opcao do menu. O main.py chama estas funcoes."""

from core import api, imagens
from janelas import personagem as janela_personagem
from terminal.busca import escolher_personagem
from terminal.menu import mostrar_avisos, mostrar_progresso


def em_construcao(nome):
    print(f"[em construcao] A opcao '{nome}' fica pronta numa proxima aula.")


def baixar_imagens(urls, descricao):
    """Baixa varias imagens mostrando uma barra de progresso. Devolve a lista de imagens."""
    fotos = []
    for numero, url in enumerate(urls, start=1):
        fotos.append(imagens.baixar_imagem(url))
        mostrar_progresso(f"Baixando {descricao}", numero, len(urls))
    return fotos


def abrindo(nome):
    print(f">> Abrindo a janela de {nome} (feche a janela para voltar ao menu)")


def opcao_ver_personagem():
    personagem = escolher_personagem()
    if personagem is None:
        return
    print("Buscando detalhes...")
    detalhe = api.detalhar_personagem(personagem["id"])
    mostrar_avisos()
    print("Baixando imagem...")
    imagem = imagens.baixar_imagem(detalhe["image"])
    urls = []
    for transformacao in detalhe["transformations"]:
        urls.append(transformacao["image"])
    fotos = baixar_imagens(urls, "transformacoes")
    abrindo(detalhe["name"])
    janela_personagem.mostrar_personagem(detalhe, imagem, fotos)


def opcao_buscar():
    em_construcao("Buscar personagens")


def opcao_batalha():
    em_construcao("Batalha")


def opcao_planetas():
    em_construcao("Planetas")


def opcao_ranking():
    em_construcao("Ranking de poder")


def opcao_quiz():
    em_construcao("Quem e esse personagem?")


def opcao_raio_x():
    em_construcao("Raio-X da API")
