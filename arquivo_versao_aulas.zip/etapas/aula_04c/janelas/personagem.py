"""Janela da Opcao 1: card do personagem + painel com descricao, planeta e transformacoes."""

import customtkinter as ctk

from janelas import base, tema
from janelas.componentes import CartaoPersonagem, preparar_foto, selo_planeta


def mostrar_personagem(personagem, imagem, fotos_transformacoes):
    """Abre a janela e so volta quando ela for fechada."""
    janela = base.criar_janela(personagem["name"], 720, 630)
    cartao = CartaoPersonagem(janela, personagem, imagem)
    cartao.grid(row=0, column=0, padx=20, pady=20, sticky="n")
    painel = criar_painel(janela, personagem, fotos_transformacoes)
    painel.grid(row=0, column=1, padx=(0, 20), pady=20, sticky="nsew")
    base.esperar_fechar(janela)


def criar_painel(janela, personagem, fotos_transformacoes):
    """Painel da direita: descricao (com rolagem), planeta de origem e botao das transformacoes."""
    painel = ctk.CTkFrame(janela, fg_color=tema.CARD, corner_radius=8)
    subtitulo(painel, "📜 Descrição (em espanhol)")
    caixa = ctk.CTkTextbox(painel, width=330, height=330, wrap="word", font=tema.fonte(14),
                           fg_color=tema.FUNDO, text_color=tema.TEXTO_SECUNDARIO)
    caixa.insert("1.0", personagem["description"])
    caixa.configure(state="disabled")             # so leitura
    caixa.pack(padx=16)

    planeta = personagem.get("originPlanet")
    if planeta:
        subtitulo(painel, "🪐 Planeta de origem")
        linha = ctk.CTkFrame(painel, fg_color="transparent")
        linha.pack(anchor="w", padx=16)
        ctk.CTkLabel(linha, text=planeta["name"], font=tema.fonte(16, negrito=True),
                     text_color=tema.DESTAQUE).pack(side="left", padx=(0, 10))
        selo_planeta(linha, planeta["isDestroyed"]).pack(side="left")

    transformacoes = personagem.get("transformations", [])
    if transformacoes:
        texto = f"Ver transformações ▶  ({len(transformacoes)})"
        # lambda = uma "mini funcao" de uma linha, que so roda quando o botao for clicado
        botao = tema.botao(painel, texto, lambda: Carrossel(janela, transformacoes, fotos_transformacoes),
                           largura=240)
        botao.pack(pady=20)
    else:
        ctk.CTkLabel(painel, text="Este personagem não tem transformações.",
                     text_color=tema.TEXTO_SECUNDARIO).pack(pady=20)
    return painel


def subtitulo(painel, texto):
    ctk.CTkLabel(painel, text=texto, font=tema.fonte(15, negrito=True),
                 text_color=tema.TEXTO).pack(anchor="w", padx=16, pady=(14, 6))


class Carrossel:
    """Janelinha que mostra as transformacoes uma de cada vez, com os botoes ◀ e ▶."""

    def __init__(self, mestre, transformacoes, fotos):
        self.transformacoes = transformacoes
        self.fotos = fotos
        self.indice = 0                    # qual transformacao esta aparecendo
        self.janela = base.criar_janela("Transformações", 340, 530, mestre)
        self.foto = ctk.CTkLabel(self.janela, text="", font=tema.fonte(16, negrito=True))
        self.foto.pack(pady=(20, 10))
        self.nome = ctk.CTkLabel(self.janela, text="", font=tema.fonte(20, negrito=True),
                                 text_color=tema.DESTAQUE)
        self.nome.pack()
        self.ki = ctk.CTkLabel(self.janela, text="", font=tema.fonte(15))
        self.ki.pack()
        self.criar_botoes()
        self.mostrar()

    def criar_botoes(self):
        linha = ctk.CTkFrame(self.janela, fg_color="transparent")
        linha.pack(pady=12)
        tema.botao(linha, "◀", self.anterior, largura=60).pack(side="left")
        self.contador = ctk.CTkLabel(linha, text="", width=90)
        self.contador.pack(side="left")
        tema.botao(linha, "▶", self.proxima, largura=60).pack(side="left")

    def mostrar(self):
        """Atualiza a foto e os textos para a transformacao da posicao self.indice."""
        transformacao = self.transformacoes[self.indice]
        self.imagem, texto = preparar_foto(self.fotos[self.indice], 280, 360)
        self.foto.configure(image=self.imagem, text=texto, compound="center")
        self.nome.configure(text=transformacao["name"])
        self.ki.configure(text=f"KI: {transformacao['ki']}")
        self.contador.configure(text=f"{self.indice + 1} de {len(self.transformacoes)}")

    def proxima(self):
        # o % faz "dar a volta": depois da ultima vem a primeira
        self.indice = (self.indice + 1) % len(self.transformacoes)
        self.mostrar()

    def anterior(self):
        self.indice = (self.indice - 1) % len(self.transformacoes)
        self.mostrar()
